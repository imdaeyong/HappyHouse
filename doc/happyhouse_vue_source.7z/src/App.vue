<template>
  <div id="app" class="container">
    <nav-header></nav-header>
    <div class="line">
          <h2 id="bg" class="text-size-50 text-center">QnA 게시판</h2>
          <hr class="break-small background-primary break-center">
        </div>
    <router-view></router-view>
    <nav-footer></nav-footer>
  </div>
</template>

<script>
import NavHeader from "./layout/Header.vue";
import NavFooter from "./layout/Footer.vue";

export default {
  name: "App",
  components: {
    NavHeader,
    NavFooter
  },
  created() {
    this.$router.push("/list");
  }
};
</script>

<style>
@import url(https://www.w3schools.com/w3css/4/w3.css);
@import url(https://maxcdn.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css);
@import url(https://www.w3schools.com/lib/w3-colors-2017.css);
@import url(https://fonts.googleapis.com/css?family=Playfair+Display&subset=latin,latin-ext);
@import url(https://fonts.googleapis.com/css?family=Open+Sans:400,300,700,800&subset=latin,latin-ext);

.router-link-exact-active {
  color: red;
}
#bg {
  z-index:1;
  position: relative;
}
#bg::after {
  content:"";
  background-image: url("./img/bar_img2.jpg");
  opacity:0.3;
  z-index: -1;
  position: absolute;
}
#menus {
  width: 100%;
  text-align: center;
}
#menus div {
  display: inline-block;
  border: 1
  px solid blue;
}
img { display: block; margin: 0px auto; }
/*
 * Components CSS - v5 - 2016-07-08
 * https://www.myresponsee.com
 * Copyright 2018, Vision Design - graphic zoo
 * Free to use under the MIT license.
*/
/* Tabs */
.tab-item {
  background: none repeat scroll 0 0 #fff;
  display: none;
  padding: 1.25rem 0;
}
.tab-item.tab-active {
  display: block;
}
.tab-content > .tab-label {
  display: none;
}
.tab-nav > .tab-label {
  float:left;
}
a.tab-label, a.tab-label:link, a.tab-label:visited, a.tab-label:hover {
  background: none repeat scroll 0 0 #262626;
  color: #fff;
  margin-right: 1px;
  padding: 0.625rem 1.25rem;
  transition: background 0.20s linear 0s;
  -o-transition: background 0.20s linear 0s;
  -ms-transition: background 0.20s linear 0s;
  -moz-transition: background 0.20s linear 0s;
  -webkit-transition: background 0.20s linear 0s;
}
a.tab-label:hover,a.tab-label.active-btn {
  background: none repeat scroll 0 0 #999;
}
.tab-label.active-btn {
  cursor: default;
}
.tab-content {
  text-align: left;
}
@media screen and (max-width:768px) {    
  .tab-nav > .tab-label {
    margin: 0.5px 0;
    width: 100%;
  }
}
/* Custom forms */
form.customform input, form.customform select, form.customform textarea, form.customform button {
 font-size:0.9rem;
 font-family:inherit;
 margin-bottom:1.25rem;
} 
form.customform input, form.customform select {height: 2.7rem;}
form.customform input, form.customform textarea, form.customform select { 
 background: none repeat scroll 0 0 #F5F5F5;
 transition: background 0.20s linear 0s;
 -o-transition: background 0.20s linear 0s;
 -ms-transition: background 0.20s linear 0s;
 -moz-transition: background 0.20s linear 0s;
 -webkit-transition: background 0.20s linear 0s;
}
form.customform input:hover, form.customform textarea:hover, form.customform select:hover, form.customform input:focus, form.customform textarea:focus, form.customform select:focus {background: none repeat scroll 0 0 #fff;}
form.customform input, form.customform textarea, form.customform select {
 background: none repeat scroll 0 0 #F5F5F5;
 border: 1px solid #E0E0E0;
 padding: 0.625rem;
 width: 100%;
}
form.customform input[type="file"] {
 border: 1px solid #E0E0E0;
 height: auto;
 max-height: 2.7rem;
 min-height: 2.7rem;
 padding: 0.4rem;
 width: 100%;
}
form.customform input[type="radio"], form.customform input[type="checkbox"] {
 margin-right: 0.625rem;
 width:auto;
 padding:0;
 height:auto;
}
form.customform option {padding: 0.625rem;}
form.customform select[multiple="multiple"] {height: auto;}
form.customform button {
 width: 100%;
 background: none repeat scroll 0 0 #152732;
 border: 0 none;
 color: #fff;
 height: 2.7rem;
 padding: 0.625rem;
 cursor:pointer;
 width: 100%;
 transition: background 0.20s linear 0s;
 -o-transition: background 0.20s linear 0s;
 -ms-transition: background 0.20s linear 0s;
 -moz-transition: background 0.20s linear 0s;
 -webkit-transition: background 0.20s linear 0s;
}
/* Tooltip */
a.tooltip-container,.tooltip-container {
  border-bottom:1px dotted;
  border-bottom-color: color;
  cursor: help;
  font-weight: 600;
}
a .tooltip-content,.tooltip-content {
  background: #152732 none repeat scroll 0 0;
  color: #fff!important;
  border-radius: 3px;
  display: none;
  font-size: 0.8rem;
  font-weight: normal;
  line-height: 1.3rem;
  margin-top: -1.25rem;
  max-width: 300px;
  padding: 0.625rem;
  position: absolute;
  z-index: 10;
}
.tooltip-content::after {
  border-left: 9px solid transparent;
  border-right: 9px solid transparent;
  border-top: 7px solid #152732;
  bottom: -5px;
  clear: both;
  content: "";
  height: 0;
  left: 50%;
  margin-left: -5px;
  position: absolute;
  width: 0;
}
a.tooltip-content.tooltip-bottom,.tooltip-content.tooltip-bottom {
  margin-top: 1.25rem;
}
.tooltip-content.tooltip-bottom::after {
  border-left: 9px solid transparent;
  border-right: 9px solid transparent;
  border-top: 0;
  border-bottom: 7px solid #152732;
  top: -5px;
}
/* Buttons */
.button,a.button,a.button:link,a.button:active,a.button:visited {
  background: #777 none repeat scroll 0 0;
  border: 0;
  color: #fff;
  cursor: pointer;
  display: inline-block;
  font-size: 0.85rem;
  padding: 0.825rem 1rem;
  text-align: center;
  transition: all 0.20s linear 0s;
  -o-transition: all 0.20s linear 0s;
  -ms-transition: all 0.20s linear 0s;
  -moz-transition: all 0.20s linear 0s;
  -webkit-transition: all 0.20s linear 0s;
}
.button.rounded-btn {
  border-radius: 4px;
}
.button.rounded-full-btn {
  border-radius: 100px;
}
.button:hover {box-shadow: 0 0 10px 100px rgba(255,255,255,0.15) inset;}
.button.secondary-btn,a.button.secondary-btn,a.button.secondary-btn:link,a.button.secondary-btn:active,a.button.secondary-btn:visited {
  background: #444 none repeat scroll 0 0;
}
.button.cancel-btn,a.button.cancel-btn,a.button.cancel-btn:link,a.button.cancel-btn:active,a.button.cancel-btn:visited {
  background: #dc003a none repeat scroll 0 0;
}
.button.submit-btn,a.button.submit-btn,a.button.submit-btn:link,a.button.submit-btn:active,a.button.submit-btn:visited {
  background: #b4bf04 none repeat scroll 0 0;
}
.button.reload-btn,a.button.reload-btn,a.button.reload-btn:link,a.button.reload-btn:active,a.button.reload-btn:visited {
  background: #ff9800 none repeat scroll 0 0;
}
.button.disabled-btn {
  cursor: not-allowed!important;
  opacity: 0.2;
}
.button i {
  background: rgba(0, 0, 0, 0.1) none repeat scroll 0 0;
  border-radius: 27px;
  color: #fff!important;
  display: inline-block;
  font-size: 0.8rem;
  height: 27px;
  line-height: 27px;
  margin-right: 5px;
  width: 27px;
  transition: all 0.20s linear 0s;
  -o-transition: all 0.20s linear 0s;
  -ms-transition: all 0.20s linear 0s;
  -moz-transition: all 0.20s linear 0s;
  -webkit-transition: all 0.20s linear 0s;
}
.button:hover > i {
  background: rgba(0, 0, 0, 0.06) none repeat scroll 0 0;
}
/*
 * Responsee CSS - v5 - 2018-01-06
 * https://www.myresponsee.com
 * Copyright 2018, Vision Design - graphic zoo
 * Free to use under the MIT license.
*/
* {  
  -webkit-box-sizing:border-box;
  -moz-box-sizing:border-box;
  box-sizing:border-box;
  margin:0;	
}
body {
  background:none repeat scroll 0 0 #eeeeee;
  font-size:16px;
  font-family:"Open Sans",Arial,sans-serif;
  color:#444;
}
h1,h2,h3,h4,h5,h6 {
  color:#152732;
  font-weight: normal;
  line-height: 1.3;
  margin:0.5rem 0;  
}
h1 {font-size:2.7rem;}
h2 {font-size:2.2rem;}  
h3 {font-size:1.8rem;}  
h4 {font-size:1.4rem;}  
h5 {font-size:1.1rem;}  
h6 {font-size:0.9rem;}    
a, a:link, a:visited, a:hover, a:active {
  text-decoration:none;
  color:#9BB800;
  transition:color 0.20s linear 0s;
  -o-transition:color 0.20s linear 0s;
  -ms-transition:color 0.20s linear 0s;
  -moz-transition:color 0.20s linear 0s;
  -webkit-transition:color 0.20s linear 0s;
}  
a:hover {color:#B6C900;}
p,li,dl,blockquote,table,kbd {
  font-size: 0.85rem;
  line-height: 1.6;
}
b,strong {font-weight:700;}
.text-center {text-align:center!important;}
.text-right {text-align:right!important;}
img {
  border:0;
  display:block;
  height:auto;
  max-width:100%;
  width:auto;
}
.owl-item img, .full-img {
  max-width: none;
  width:100%;
}
.owl-nav div {font-family: "mfg";}  
table {
  background:none repeat scroll 0 0 #fff;
  border:1px solid #f0f0f0;
  border-collapse:collapse;
  border-spacing:0;
  text-align:left;
  width:100%;
}
table tr td, table tr th {padding:0.625rem;}
table tfoot, table thead,table tr:nth-of-type(2n) {background:none repeat scroll 0 0 #f0f0f0;}
th,table tr:nth-of-type(2n) td {border-right:1px solid #fff;}
td {border-right:1px solid #f0f0f0;}
.size-960 .line,.size-1140 .line,.size-1280 .line,.size-1520 .line {
  margin:0 auto;
  padding:0 0.625rem;
}
hr {
  border: 0;
  border-top: 1px solid #e5e5e5;
  clear:both;  
  height:0; 
  margin:2.5rem auto;
}
li {padding:0;}
ul,ol {padding-left:1.25rem;}
blockquote {
  border:2px solid #f0f0f0;
  padding:1.25rem;
}
cite {
  color:#999;
  display:block;
  font-size:0.8rem;
}
cite:before {content:"— ";}
dl dt {font-weight:700;}
dl dd {margin-bottom:0.625rem;}
dl dd:last-child {margin-bottom:0;}
abbr {cursor:help;}
abbr[title] {border-bottom:1px dotted;}
kbd {
  background: #152732 none repeat scroll 0 0;
  color: #fff;
  padding: 0.125rem 0.3125rem;
}
code, kbd, pre, samp {font-family: Menlo,Monaco,Consolas,"Courier New",monospace;}
mark {
  background: #F3F8A9 none repeat scroll 0 0;
  padding: 0.125rem 0.3125rem;
}
.size-960 .line {max-width:59.75rem;}
.size-1140 .line {max-width:71rem;}
.size-1280 .line {max-width:80rem;}
.size-1520 .line {max-width:95rem;}
.size-960.align-content-left .line,.size-1140.align-content-left .line,.size-1280.align-content-left .line,.size-1520.align-content-left .line {margin-left:0;}
form {line-height:1.4;}
nav {
  display:block;
  width:100%;
  background:#152732;
}
.line:after, nav:after, .center:after, .box:after, .margin:after, .margin2x:after {
  clear:both;
  content:".";
  display:block;
  height:0;
  line-height:0;
  overflow: hidden;
  visibility:hidden;
}
.top-nav ul {padding:0;}
.top-nav ul ul {
  position:absolute;
  background:#152732;
}
.top-nav li {
  float:left;
  list-style:none outside none;
  cursor:pointer;
}
.top-nav li a {
  color:#fff; 
  display:block;
  font-size:1rem;
  padding:1.25rem; 
}
.top-nav li ul li a {
  background:none repeat scroll 0 0 #152732;
  min-width:100%;
  padding:0.625rem;
}
.top-nav li a:hover, .aside-nav li a:hover {background:#2b4c61;}
.top-nav li ul {display:none;}
.top-nav li ul li,.top-nav li ul li ul li {
  float:none;
  list-style:none outside none;
  min-width:100%;
  padding:0;
}
.count-number {
  background: rgba(153, 153, 153, 0.25) none repeat scroll 0 0;
  border-radius: 10rem;
  color: #fff;
  display: inline-block;
  font-size: 0.7rem;
  height: 1.3rem;
  line-height: 1.3rem; 
  margin: 0 0 -0.3125rem 0.3125rem;
  text-align: center;
  width: 1.3rem;
}
ul.chevron .count-number {display:none;}
ul.chevron .submenu > a:after, ul.chevron .sub-submenu > a:after,ul.chevron .aside-submenu > a:after, ul.chevron .aside-sub-submenu > a:after {
  content:"\f004";
  display:inline-block;
  font-family:mfg;
  font-size:0.7rem;
  margin:0 0.625rem;
}
.top-nav .active-item a {background:#2b4c61;}
.aside-nav > ul > li.active-item > a:link,.aside-nav > ul > li.active-item > a:visited {
  background:#2b4c61;
  color:#fff;
}
@media screen and (min-width:769px) {
  .aside-nav .count-number {
	  margin-left:-1.25rem;	
	  float:right;	
  }
  .top-nav li:hover > ul {
	  display:block;
	  z-index:10;
  }  
  .top-nav li:hover > ul ul {
    left:100%;
    margin:-2.5rem 0;
    width:100%;
  } 
}
.nav-text,.aside-nav-text {display:none;}
.aside-nav a,.aside-nav a:link,.aside-nav a:visited,.aside-nav li > ul,.top-nav a,.top-nav a:link,.top-nav a:visited {
  transition:background 0.20s linear 0s;
  -o-transition:background 0.20s linear 0s;
  -ms-transition:background 0.20s linear 0s;
  -moz-transition:background 0.20s linear 0s;
  -webkit-transition:background 0.20s linear 0s;
}
.aside-nav ul {
  background:#e8e8e8; 
  padding:0;
}
.aside-nav li {
  list-style:none outside none;
  cursor:pointer;
}
.aside-nav li a,.aside-nav li a:link,.aside-nav li a:visited {
  color:#444;
  display:block;
  font-size:1rem;
  padding:1.25rem;
}
.aside-nav > ul > li:last-child a {border-bottom:0 none;}
.aside-nav li > ul {
  height:0;
  display:block;
  position:relative;
  background:#f4f4f4;
  border-left:solid 1px #f2f2f2;
  border-right:solid 1px #f2f2f2;
  overflow:hidden;
}
.aside-nav li ul ul {
  border:0;
  background:#fff;
}
.aside-nav ul ul a {padding:0.625rem 1.25rem;}
.aside-nav li a:link, .aside-nav li a:visited {color:#333;}
.aside-nav li li a:hover, .aside-nav li li.active-item > a, .aside-nav li li.aside-sub-submenu li a:hover {
  color:#fff;
  background:#2b4c61;
}
.aside-nav > ul > li > a:hover {color:#fff;}
.aside-nav li li a:link, .aside-nav li li a:visited {background:none;}
.aside-nav .show-aside-ul, .aside-nav .active-aside-item {height:auto;} 
nav.breadcrumb-nav {
  background:#fff;
  margin:0.625rem 0;
}
nav.breadcrumb-nav ul {
  list-style:none;
  padding:0;
}
nav.breadcrumb-nav ul li {float:left;}
nav.breadcrumb-nav ul li a:hover {text-decoration:underline;}
.breadcrumb-nav i {color:#B6C900;}
nav.breadcrumb-nav ul li:after {
  content:"/";
  margin:0 9px;
  color:#c8c7c7;
}
nav.breadcrumb-nav ul li:last-child:after {content:"";}
.slide-content, .slide-nav {
  transition:all 0.10s linear 0s;
  -o-transition:all 0.10s linear 0s;
  -ms-transition:all 0.10s linear 0s;
  -moz-transition:all 0.10s linear 0s;
  -webkit-transition:all 0.10s linear 0s;
}
.slide-content {
  float:left;
  width:calc(100% - 60px);  
}
.aside-nav.slide-nav {
  background:#1c3849;
  bottom:0; 
  right:0;
  top:0;
  margin-right:-180px;     
  overflow-y:auto;
  padding-top:0.625rem;
  position:fixed;
  width:240px;
  z-index:2;
}
.aside-nav.slide-nav > ul {
  background:#1c3849;
  opacity:0;
  transition:all 0.20s linear 0s;
  -o-transition:all 0.20s linear 0s;
  -ms-transition:all 0.20s linear 0s;
  -moz-transition:all 0.20s linear 0s;
  -webkit-transition:all 0.20s linear 0s;
}
.aside-nav.slide-nav li a, .aside-nav.slide-nav li a:link, .aside-nav.slide-nav li a:visited {
  color:#fff;
  display:block;
  font-size:0.9rem;
  padding:0.625rem 1.25rem;
  border-bottom:0;
}
.aside-nav.slide-nav li a:hover {
  background:#152732!important;
  color:#fff!important;
}
.aside-nav.slide-nav li > ul {
  background:#2b4c61;
  border-left:0;
  border-right:0;
}
.aside-nav.slide-nav li > ul ul {
  background:#456274;
  border-left:0;
  border-right:0;
}
.slide-nav-button {
  background:#152732;
  cursor:pointer;
  position:fixed;
  top:0;
  right:0;
  bottom:0;
  width:60px;
  z-index:3;
}
.active-slide-nav .slide-content {margin-left:-240px;}
.active-slide-nav .slide-nav {margin-right:60px;}
.slide-to-left .slide-content {float:right;}
.slide-to-left .slide-nav {
  left:0;
  margin-right:0; 
  margin-left:-180px;    
}
.slide-to-left .slide-nav-button {left:0;}
.slide-to-left.active-slide-nav .slide-content {
  margin-right:-240px;
  margin-left:0;
}
.slide-to-left.active-slide-nav .slide-nav {
  margin-right:0;
  margin-left:60px;
}
.active-slide-nav .slide-nav ul {opacity:1;}
.nav-icon {
  padding:0.9rem;
  width:100%;
}
.nav-icon:after,.nav-icon:before,.nav-icon div {
  background-color:#fff;
  border-radius:3px;
  content:'';
  display:block;
  height:3px;
  margin:6px 0;
  transition:all 0.2s ease-in-out;
  -moz-transition:all 0.2s ease-in-out;
  -webkit-transition:all 0.2s ease-in-out;
}
.active-slide-nav .nav-icon:before {
  transform:translateY(9px) rotate(135deg);
  -moz-transform:translateY(9px) rotate(135deg);
  -webkit-transform:translateY(9px) rotate(135deg);
}
.active-slide-nav .nav-icon:after {
  transform:translateY(-9px) rotate(-135deg);
  -moz-transform:translateY(-9px) rotate(-135deg);
  -webkit-transform:translateY(-9px) rotate(-135deg);
}
.active-slide-nav .nav-icon div {
  transform:scale(0);
  -moz-transform:scale(0);
  -webkit-transform:scale(0);  
}
.active-slide-nav {overflow-x:hidden;} 
.padding {
  display:list-item;
  list-style:none outside none;
  padding:0.625rem;
}
.margin,.margin2x {display: block;}
.margin {margin:0 -0.625rem;}
.margin2x {margin:0 -1.25rem;}
.line {clear:left;}
.line .line {padding:0;}
.hide-xxl {display:none!important;}
.box {
  background:none repeat scroll 0 0 #fff;
  display:block;
  padding:1.25rem;
  width:100%;
}
.margin-bottom {margin-bottom:1.25rem;}
.margin-bottom2x {margin-bottom:2.5rem;}
.s-1,.s-2,.s-five,.s-3,.s-4,.s-5,.s-6,.s-7,.s-8,.s-9,.s-10,.s-11,.s-12,.m-1,.m-2,.m-five,.m-3,.m-4,.m-5,.m-6,.m-7,.m-8,.m-9,.m-10,.m-11,.m-12,.l-1,.l-2,.l-five,.l-3,.l-4,.l-5,.l-6,.l-7,.l-8,.l-9,.l-10,.l-11,.l-12,.xl-1,.xl-2,.xl-five,.xl-3,.xl-4,.xl-5,.xl-6,.xl-7,.xl-8,.xl-9,.xl-10,.xl-11,.xl-12,.xxl-1,.xxl-2,.xxl-five,.xxl-3,.xxl-4,.xxl-5,.xxl-6,.xxl-7,.xxl-8,.xxl-9,.xxl-10,.xxl-11,.xxl-12 {
  float:left;
  position:static;
}
.xxl-offset-1 {margin-left:8.3333%;}
.xxl-offset-2 {margin-left:16.6666%;}
.xxl-offset-five {margin-left:20%;}
.xxl-offset-3 {margin-left:25%;}
.xxl-offset-4 {margin-left:33.3333%;}
.xxl-offset-5 {margin-left:41.6666%;}
.xxl-offset-6 {margin-left:50%;}
.xxl-offset-7 {margin-left:58.3333%;}
.xxl-offset-8 {margin-left:66.6666%;}
.xxl-offset-9 {margin-left:75%;}
.xxl-offset-10 {margin-left:83.3333%;}
.xxl-offset-11 {margin-left:91.6666%;}
.xxl-offset-12 {margin-left:100%;} 
.margin > .s-1,.margin > .s-2,.margin > .s-five,.margin > .s-3,.margin > .s-4,.margin > .s-5,.margin > .s-6,.margin > .s-7,.margin > .s-8,.margin > .s-9,.margin > .s-10,.margin > .s-11,.margin > .s-12,
.margin > .m-1,.margin > .m-2,.margin > .m-five,.margin > .m-3,.margin > .m-4,.margin > .m-5,.margin > .m-6,.margin > .m-7,.margin > .m-8,.margin > .m-9,.margin > .m-10,.margin > .m-11,.margin > .m-12,
.margin > .l-1,.margin > .l-2,.margin > .l-five,.margin > .l-3,.margin > .l-4,.margin > .l-5,.margin > .l-6,.margin > .l-7,.margin > .l-8,.margin > .l-9,.margin > .l-10,.margin > .l-11,.margin > .l-12,
.margin > .xl-1,.margin > .xl-2,.margin > .xl-five,.margin > .xl-3,.margin > .xl-4,.margin > .xl-5,.margin > .xl-6,.margin > .xl-7,.margin > .xl-8,.margin > .xl-9,.margin > .xl-10,.margin > .xl-11,.margin > .xl-12,
.margin > .xxl-1,.margin > .xxl-2,.margin > .xxl-five,.margin > .xxl-3,.margin > .xxl-4,.margin > .xxl-5,.margin > .xxl-6,.margin > .xxl-7,.margin > .xxl-8,.margin > .xxl-9,.margin > .xxl-10,.margin > .xxl-11,.margin > .xxl-12 {padding:0 0.625rem;}
.margin2x > .s-1,.margin2x > .s-2,.margin2x > .s-five,.margin2x > .s-3,.margin2x > .s-4,.margin2x > .s-5,.margin2x > .s-6,.margin2x > .s-7,.margin2x > .s-8,.margin2x > .s-9,.margin2x > .s-10,.margin2x > .s-11,.margin2x > .s-12,
.margin2x > .m-1,.margin2x > .m-2,.margin2x > .m-five,.margin2x > .m-3,.margin2x > .m-4,.margin2x > .m-5,.margin2x > .m-6,.margin2x > .m-7,.margin2x > .m-8,.margin2x > .m-9,.margin2x > .m-10,.margin2x > .m-11,.margin2x > .m-12,
.margin2x > .l-1,.margin2x > .l-2,.margin2x > .l-five,.margin2x > .l-3,.margin2x > .l-4,.margin2x > .l-5,.margin2x > .l-6,.margin2x > .l-7,.margin2x > .l-8,.margin2x > .l-9,.margin2x > .l-10,.margin2x > .l-11,.margin2x > .l-12,
.margin2x > .xl-1,.margin2x > .xl-2,.margin2x > .xl-five,.margin2x > .xl-3,.margin2x > .xl-4,.margin2x > .xl-5,.margin2x > .xl-6,.margin2x > .xl-7,.margin2x > .xl-8,.margin2x > .xl-9,.margin2x > .xl-10,.margin2x > .xl-11,.margin2x > .xl-12,
.margin2x > .xxl-1,.margin2x > .xxl-2,.margin2x > .xxl-five,.margin2x > .xxl-3,.margin2x > .xxl-4,.margin2x > .xxl-5,.margin2x > .xxl-6,.margin2x > .xxl-7,.margin2x > .xxl-8,.margin2x > .xxl-9,.margin2x > .xxl-10,.margin2x > .xxl-11,.margin2x > .xxl-12 {padding:0 1.25rem;}
.s-1 {width:8.3333%;}
.s-2 {width:16.6666%;}
.s-five {width:20%;}
.s-3 {width:25%;}
.s-4 {width:33.3333%;}
.s-5 {width:41.6666%;}
.s-6 {width:50%;}
.s-7 {width:58.3333%;}
.s-8 {width:66.6666%;}
.s-9 {width:75%;}
.s-10 {width:83.3333%;}
.s-11 {width:91.6666%;}
.s-12 {width:100%;}
.m-1 {width:8.3333%;}
.m-2 {width:16.6666%;}
.m-five {width:20%;}
.m-3 {width:25%;}
.m-4 {width:33.3333%;}
.m-5 {width:41.6666%;}
.m-6 {width:50%;}
.m-7 {width:58.3333%;}
.m-8 {width:66.6666%;}
.m-9 {width:75%;}
.m-10 {width:83.3333%;}
.m-11 {width:91.6666%;}
.m-12 {width:100%;}
.l-1 {width:8.3333%;}
.l-2 {width:16.6666%;}
.l-five {width:20%;}
.l-3 {width:25%;}
.l-4 {width:33.3333%;}
.l-5 {width:41.6666%;}
.l-6 {width:50%;}
.l-7 {width:58.3333%;}
.l-8 {width:66.6666%;}
.l-9 {width:75%;}
.l-10 {width:83.3333%;}
.l-11 {width:91.6666%;}
.l-12 {width:100%;}
.xl-1 {width:8.3333%;}
.xl-2 {width:16.6666%;}
.xl-five {width:20%;}
.xl-3 {width:25%;}
.xl-4 {width:33.3333%;}
.xl-5 {width:41.6666%;}
.xl-6 {width:50%;}
.xl-7 {width:58.3333%;}
.xl-8 {width:66.6666%;}
.xl-9 {width:75%;}
.xl-10 {width:83.3333%;}
.xl-11 {width:91.6666%;}
.xl-12 {width:100%;}
.xxl-1 {width:8.3333%;}
.xxl-2 {width:16.6666%;}
.xxl-five {width:20%;}
.xxl-3 {width:25%;}
.xxl-4 {width:33.3333%;}
.xxl-5 {width:41.6666%;}
.xxl-6 {width:50%;}
.xxl-7 {width:58.3333%;}
.xxl-8 {width:66.6666%;}
.xxl-9 {width:75%;}
.xxl-10 {width:83.3333%;}
.xxl-11 {width:91.6666%;}
.xxl-12 {width:100%;}
.right {float:right;}
.left {float:left;} 

@media screen and (max-width:1366px) {
  .hide-xxl,.hide-l,.hide-m,.hide-s {display:initial!important;}
  .hide-xl {display:none!important;}
  .size-960,.size-1140,.size-1280,.size-1520 {max-width:1366px;}
  .xxl-offset-1,.xxl-offset-2,.xxl-offset-five,.xxl-offset-3,.xxl-offset-4,.xxl-offset-5,.xxl-offset-6,.xxl-offset-7,.xxl-offset-8,.xxl-offset-9,.xxl-offset-10,.xxl-offset-11,.xxl-offset-12 {margin-left:0;}
  .xl-offset-1 {margin-left:8.3333%;}
  .xl-offset-2 {margin-left:16.6666%;}
  .xl-offset-five {margin-left:20%;}
  .xl-offset-3 {margin-left:25%;}
  .xl-offset-4 {margin-left:33.3333%;}
  .xl-offset-5 {margin-left:41.6666%;}
  .xl-offset-6 {margin-left:50%;}
  .xl-offset-7 {margin-left:58.3333%;}
  .xl-offset-8 {margin-left:66.6666%;}
  .xl-offset-9 {margin-left:75%;}
  .xl-offset-10 {margin-left:83.3333%;}
  .xl-offset-11 {margin-left:91.6666%;}
  .xl-offset-12 {margin-left:100%;} 
  .xxl-1 {width:8.3333%;}
  .xxl-2 {width:16.6666%;}
  .xxl-five {width:20%;}
  .xxl-3 {width:25%;}
  .xxl-4 {width:33.3333%;}
  .xxl-5 {width:41.6666%;}
  .xxl-6 {width:50%;}
  .xxl-7 {width:58.3333%;}
  .xxl-8 {width:66.6666%;}
  .xxl-9 {width:75%;}
  .xxl-10 {width:83.3333%;}
  .xxl-11 {width:91.6666%;}
  .xxl-12 {width:100%;}
  .s-1 {width:8.3333%;}
  .s-2 {width:16.6666%;}
  .s-five {width:20%;}
  .s-3 {width:25%;}
  .s-4 {width:33.3333%;}
  .s-5 {width:41.6666%;}
  .s-6 {width:50%;}
  .s-7 {width:58.3333%;}
  .s-8 {width:66.6666%;}
  .s-9 {width:75%;}
  .s-10 {width:83.3333%;}
  .s-11 {width:91.6666%;}
  .s-12 {width:100%}
  .m-1 {width:8.3333%;}
  .m-2 {width:16.6666%;}
  .m-five {width:20%;}
  .m-3 {width:25%;}
  .m-4 {width:33.3333%;}
  .m-5 {width:41.6666%;}
  .m-6 {width:50%;}
  .m-7 {width:58.3333%;}
  .m-8 {width:66.6666%;}
  .m-9 {width:75%;}
  .m-10 {width:83.3333%;}
  .m-11 {width:91.6666%;}
  .m-12 {width:100%}
  .l-1 {width:8.3333%;}
  .l-2 {width:16.6666%;}
  .l-five {width:20%;}
  .l-3 {width:25%;}
  .l-4 {width:33.3333%;}
  .l-5 {width:41.6666%;}
  .l-6 {width:50%;}
  .l-7 {width:58.3333%;}
  .l-8 {width:66.6666%;}
  .l-9 {width:75%;}
  .l-10 {width:83.3333%;}
  .l-11 {width:91.6666%;}
  .l-12 {width:100%;}
  .xl-1 {width:8.3333%;}
  .xl-2 {width:16.6666%;}
  .xl-five {width:20%;}
  .xl-3 {width:25%;}
  .xl-4 {width:33.3333%;}
  .xl-5 {width:41.6666%;}
  .xl-6 {width:50%;}
  .xl-7 {width:58.3333%;}
  .xl-8 {width:66.6666%;}
  .xl-9 {width:75%;}
  .xl-10 {width:83.3333%;}
  .xl-11 {width:91.6666%;}
  .xl-12 {width:100%;}
}

@media screen and (max-width:1140px) {
  .hide-xxl,.hide-xl,.hide-m,.hide-s {display:initial!important;}
  .hide-l {display:none!important;}
  .size-960,.size-1140,.size-1280,.size-1520 {max-width:1140px;}
  .xl-offset-1,.xl-offset-2,.xl-offset-five,.xl-offset-3,.xl-offset-4,.xl-offset-5,.xl-offset-6,.xl-offset-7,.xl-offset-8,.xl-offset-9,.xl-offset-10,.xl-offset-11,.xl-offset-12 {margin-left:0;}
  .l-offset-1 {margin-left:8.3333%;}
  .l-offset-2 {margin-left:16.6666%;}
  .l-offset-five {margin-left:20%;}
  .l-offset-3 {margin-left:25%;}
  .l-offset-4 {margin-left:33.3333%;}
  .l-offset-5 {margin-left:41.6666%;}
  .l-offset-6 {margin-left:50%;}
  .l-offset-7 {margin-left:58.3333%;}
  .l-offset-8 {margin-left:66.6666%;}
  .l-offset-9 {margin-left:75%;}
  .l-offset-10 {margin-left:83.3333%;}
  .l-offset-11 {margin-left:91.6666%;}
  .l-offset-12 {margin-left:100%;}
  .xxl-1 {width:8.3333%;}
  .xxl-2 {width:16.6666%;}
  .xxl-five {width:20%;}
  .xxl-3 {width:25%;}
  .xxl-4 {width:33.3333%;}
  .xxl-5 {width:41.6666%;}
  .xxl-6 {width:50%;}
  .xxl-7 {width:58.3333%;}
  .xxl-8 {width:66.6666%;}
  .xxl-9 {width:75%;}
  .xxl-10 {width:83.3333%;}
  .xxl-11 {width:91.6666%;}
  .xxl-12 {width:100%;} 
  .xl-1 {width:8.3333%;}
  .xl-2 {width:16.6666%;}
  .xl-five {width:20%;}
  .xl-3 {width:25%;}
  .xl-4 {width:33.3333%;}
  .xl-5 {width:41.6666%;}
  .xl-6 {width:50%;}
  .xl-7 {width:58.3333%;}
  .xl-8 {width:66.6666%;}
  .xl-9 {width:75%;}
  .xl-10 {width:83.3333%;}
  .xl-11 {width:91.6666%;}
  .xl-12 {width:100%;}
  .s-1 {width:8.3333%;}
  .s-2 {width:16.6666%;}
  .s-five {width:20%;}
  .s-3 {width:25%;}
  .s-4 {width:33.3333%;}
  .s-5 {width:41.6666%;}
  .s-6 {width:50%;}
  .s-7 {width:58.3333%;}
  .s-8 {width:66.6666%;}
  .s-9 {width:75%;}
  .s-10 {width:83.3333%;}
  .s-11 {width:91.6666%;}
  .s-12 {width:100%}
  .m-1 {width:8.3333%;}
  .m-2 {width:16.6666%;}
  .m-five {width:20%;}
  .m-3 {width:25%;}
  .m-4 {width:33.3333%;}
  .m-5 {width:41.6666%;}
  .m-6 {width:50%;}
  .m-7 {width:58.3333%;}
  .m-8 {width:66.6666%;}
  .m-9 {width:75%;}
  .m-10 {width:83.3333%;}
  .m-11 {width:91.6666%;}
  .m-12 {width:100%}
  .l-1 {width:8.3333%;}
  .l-2 {width:16.6666%;}
  .l-five {width:20%;}
  .l-3 {width:25%;}
  .l-4 {width:33.3333%;}
  .l-5 {width:41.6666%;}
  .l-6 {width:50%;}
  .l-7 {width:58.3333%;}
  .l-8 {width:66.6666%;}
  .l-9 {width:75%;}
  .l-10 {width:83.3333%;}
  .l-11 {width:91.6666%;}
  .l-12 {width:100%;}
}
 
@media screen and (max-width:768px) {
  .size-960,.size-1140,.size-1280,.size-1520 {max-width:768px;}
  .hide-xxl,.hide-xl,.hide-l,.hide-s {display:initial!important;}
  .hide-m {display:none!important;}
  nav {
    display:block;
    cursor:pointer;
    line-height:3;
  }
  .top-nav li a {background:none repeat scroll 0 0 #1c3849;}
  .top-nav > ul {
    height:0;
    max-width:100%;
    overflow:hidden;
    position:relative;
    z-index:999;
  }
  .top-nav > ul.show-menu,.aside-nav.minimize-on-small > ul.show-menu {height:auto;}
  .top-nav ul ul {
    left:0;
    margin-top:0;
    position:relative;
    right:0;
  } 
  .top-nav li ul li a {min-width:100%;}
  .top-nav li {
    float:none;
    list-style:none outside none;
    padding:0;
  }
  .top-nav li a {
    color:#fff;
    display:block;
    padding:1.25rem 0.625rem;
    text-align:center;
    text-decoration:none;
  }
  .top-nav li a:hover {
    background:none repeat scroll 0 0 #152732;
    color:#fff;
  }
  .top-nav li ul,.top-nav li ul li ul {
    display:block;  
    overflow:hidden; 
    height:0;   
  } 
  .top-nav > ul ul.show-ul {
    display:block;
    height:auto;  
  }
  .top-nav li ul li a {
    background:none repeat scroll 0 0 #2b4c61;
    padding:0.625rem;
  }
  .top-nav li ul li ul li a { background:none repeat scroll 0 0 #456274;}
  .nav-text {
    color:#fff;
    display:block;
    font-size:1.2rem;
    line-height:3;
    margin-right:0.625rem;
    max-width:100%;
    text-align:center;
    vertical-align:middle;
  }
  .nav-text:after {
    content:"\f008";
    font-family:"mfg";
    font-size:1.1rem;
    margin-left:0.5rem;
    text-align:right;
  }
  .l-offset-1,.l-offset-2,.l-offset-five,.l-offset-3,.l-offset-4,.l-offset-5,.l-offset-6,.l-offset-7,.l-offset-8,.l-offset-9,.l-offset-10,.l-offset-11,.l-offset-12,
  .xl-offset-1,.xl-offset-2,.xl-offset-five,.xl-offset-3,.xl-offset-4,.xl-offset-5,.xl-offset-6,.xl-offset-7,.xl-offset-8,.xl-offset-9,.xl-offset-10,.xl-offset-11,.xl-offset-12,
  .xxl-offset-1,.xxl-offset-2,.xxl-offset-five,.xxl-offset-3,.xxl-offset-4,.xxl-offset-5,.xxl-offset-6,.xxl-offset-7,.xxl-offset-8,.xxl-offset-9,.xxl-offset-10,.xxl-offset-11,.xxl-offset-12 {margin-left:0;}
  .m-offset-1 {margin-left:8.3333%;}
  .m-offset-2 {margin-left:16.6666%;}
  .m-offset-five {margin-left:20%;}
  .m-offset-3 {margin-left:25%;}
  .m-offset-4 {margin-left:33.3333%;}
  .m-offset-5 {margin-left:41.6666%;}
  .m-offset-6 {margin-left:50%;}
  .m-offset-7 {margin-left:58.3333%;}
  .m-offset-8 {margin-left:66.6666%;}
  .m-offset-9 {margin-left:75%;}
  .m-offset-10 {margin-left:83.3333%;}
  .m-offset-11 {margin-left:91.6666%;}
  .m-offset-12 {margin-left:100%;}
  .xxl-1 {width:8.3333%;}
  .xxl-2 {width:16.6666%;}
  .xxl-five {width:20%;}
  .xxl-3 {width:25%;}
  .xxl-4 {width:33.3333%;}
  .xxl-5 {width:41.6666%;}
  .xxl-6 {width:50%;}
  .xxl-7 {width:58.3333%;}
  .xxl-8 {width:66.6666%;}
  .xxl-9 {width:75%;}
  .xxl-10 {width:83.3333%;}
  .xxl-11 {width:91.6666%;}
  .xxl-12 {width:100%;}
  .xl-1 {width:8.3333%;}
  .xl-2 {width:16.6666%;}
  .xl-five {width:20%;}
  .xl-3 {width:25%;}
  .xl-4 {width:33.3333%;}
  .xl-5 {width:41.6666%;}
  .xl-6 {width:50%;}
  .xl-7 {width:58.3333%;}
  .xl-8 {width:66.6666%;}
  .xl-9 {width:75%;}
  .xl-10 {width:83.3333%;}
  .xl-11 {width:91.6666%;}
  .xl-12 {width:100%;} 
  .l-1 {width:8.3333%;}
  .l-2 {width:16.6666%;}
  .l-five {width:20%;}
  .l-3 {width:25%;}
  .l-4 {width:33.3333%;}
  .l-5 {width:41.6666%;}
  .l-6 {width:50%;}
  .l-7 {width:58.3333%;}
  .l-8 {width:66.6666%;}
  .l-9 {width:75%;}
  .l-10 {width:83.3333%;}
  .l-11 {width:91.6666%;}
  .l-12 {width:100%;}
  .s-1 {width:8.3333%;}
  .s-2 {width:16.6666%;}
  .s-five {width:20%;}
  .s-3 {width:25%;}
  .s-4 {width:33.3333%;}
  .s-5 {width:41.6666%;}
  .s-6 {width:50%;}
  .s-7 {width:58.3333%;}
  .s-8 {width:66.6666%;}
  .s-9 {width:75%;}
  .s-10 {width:83.3333%;}
  .s-11 {width:91.6666%;}
  .s-12 {width:100%}
  .m-1 {width:8.3333%;}
  .m-2 {width:16.6666%;}
  .m-five {width:20%;}
  .m-3 {width:25%;}
  .m-4 {width:33.3333%;}
  .m-5 {width:41.6666%;}
  .m-6 {width:50%;}
  .m-7 {width:58.3333%;}
  .m-8 {width:66.6666%;}
  .m-9 {width:75%;}
  .m-10 {width:83.3333%;}
  .m-11 {width:91.6666%;}
  .m-12 {width:100%}
}

@media screen and (max-width:480px) {
  .size-960,.size-1140,.size-1280,.size-1520 {max-width:480px;}
  .aside-nav li a {text-align: center;}
  .minimize-on-small .aside-nav-text {
    background:#152732 none repeat scroll 0 0;
    color:#fff;
    cursor:pointer;
    display:block;
    font-size:1.2rem;
    line-height:3;
    max-width:100%;
    padding-right:0.625rem;
    text-align:center;
    vertical-align:middle;
  }
  .aside-nav-text:after {
    content:"\f008";
    font-family:"mfg";
    font-size:1.1rem;
    margin-left:0.5rem;
    text-align:right;
  }
  .aside-nav.minimize-on-small > ul {
    height:0;
    overflow:hidden;
  }
  .hide-xxl,.hide-xl,.hide-l,.hide-m {display:initial!important;}
  .hide-s {display:none!important;}
  .count-number {margin-right:-1.25rem;} 
  .m-offset-1,.m-offset-2,.m-offset-five,.m-offset-3,.m-offset-4,.m-offset-5,.m-offset-6,.m-offset-7,.m-offset-8,.m-offset-9,.m-offset-10,.m-offset-11,.m-offset-12,
  .l-offset-1,.l-offset-2,.l-offset-five,.l-offset-3,.l-offset-4,.l-offset-5,.l-offset-6,.l-offset-7,.l-offset-8,.l-offset-9,.l-offset-10,.l-offset-11,.l-offset-12,
  .xl-offset-1,.xl-offset-2,.xl-offset-five,.xl-offset-3,.xl-offset-4,.xl-offset-5,.xl-offset-6,.xl-offset-7,.xl-offset-8,.xl-offset-9,.xl-offset-10,.xl-offset-11,.xl-offset-12,
  .xxl-offset-1,.xxl-offset-2,.xxl-offset-five,.xxl-offset-3,.xxl-offset-4,.xxl-offset-5,.xxl-offset-6,.xxl-offset-7,.xxl-offset-8,.xxl-offset-9,.xxl-offset-10,.xxl-offset-11,.xxl-offset-12 {margin-left:0;}
  .s-offset-1 {margin-left:8.3333%;}
  .s-offset-2 {margin-left:16.6666%;}
  .s-offset-five {margin-left:20%;}
  .s-offset-3 {margin-left:25%;}
  .s-offset-4 {margin-left:33.3333%;}
  .s-offset-5 {margin-left:41.6666%;}
  .s-offset-6 {margin-left:50%;}
  .s-offset-7 {margin-left:58.3333%;}
  .s-offset-8 {margin-left:66.6666%;}
  .s-offset-9 {margin-left:75%;}
  .s-offset-10 {margin-left:83.3333%;}
  .s-offset-11 {margin-left:91.6666%;}
  .s-offset-12 {margin-left:100%;}
  .xxl-1 {width:8.3333%;}
  .xxl-2 {width:16.6666%;}
  .xxl-five {width:20%;}
  .xxl-3 {width:25%;}
  .xxl-4 {width:33.3333%;}
  .xxl-5 {width:41.6666%;}
  .xxl-6 {width:50%;}
  .xxl-7 {width:58.3333%;}
  .xxl-8 {width:66.6666%;}
  .xxl-9 {width:75%;}
  .xxl-10 {width:83.3333%;}
  .xxl-11 {width:91.6666%;}
  .xxl-12 {width:100%;} 
  .xl-1 {width:8.3333%;}
  .xl-2 {width:16.6666%;}
  .xl-five {width:20%;}
  .xl-3 {width:25%;}
  .xl-4 {width:33.3333%;}
  .xl-5 {width:41.6666%;}
  .xl-6 {width:50%;}
  .xl-7 {width:58.3333%;}
  .xl-8 {width:66.6666%;}
  .xl-9 {width:75%;}
  .xl-10 {width:83.3333%;}
  .xl-11 {width:91.6666%;}
  .xl-12 {width:100%;}
  .l-1 {width:8.3333%;}
  .l-2 {width:16.6666%;}
  .l-five {width:20%;}
  .l-3 {width:25%;}
  .l-4 {width:33.3333%;}
  .l-5 {width:41.6666%;}
  .l-6 {width:50%;}
  .l-7 {width:58.3333%;}
  .l-8 {width:66.6666%;}
  .l-9 {width:75%;}
  .l-10 {width:83.3333%;}
  .l-11 {width:91.6666%;}
  .l-12 {width:100%;}
  .m-1 {width:8.3333%;}
  .m-2 {width:16.6666%;}
  .m-five {width:20%;}
  .m-3 {width:25%;}
  .m-4 {width:33.3333%;}
  .m-5 {width:41.6666%;}
  .m-6 {width:50%;}
  .m-7 {width:58.3333%;}
  .m-8 {width:66.6666%;}
  .m-9 {width:75%;}
  .m-10 {width:83.3333%;}
  .m-11 {width:91.6666%;}
  .m-12 {width:100%}
  .s-1 {width:8.3333%;}
  .s-2 {width:16.6666%;}
  .s-five {width:20%;}
  .s-3 {width:25%;}
  .s-4 {width:33.3333%;}
  .s-5 {width:41.6666%;}
  .s-6 {width:50%;}
  .s-7 {width:58.3333%;}
  .s-8 {width:66.6666%;}
  .s-9 {width:75%;}
  .s-10 {width:83.3333%;}
  .s-11 {width:91.6666%;}
  .s-12 {width:100%}
}  
.center {
  float:none;
  margin:0 auto;
  display:block;
}
/* Default Template Styles */

/* Typography */
body {
  background: #fff;
}
p {
  color: #777;
  font-size: 0.85rem;
  line-height: 1.6rem;
}
a, a:link, a:visited, a:hover, a:active { 
color: #777;
}
h1, h2, h3, h4, h5, h6, .h1, .h2, .h3, .h4, .h5, .h6 {
  color: #000;                                         
  margin-bottom: 15px;
  margin-top: 0;
}
h1, .h1 {
  font-size: 1.8rem;
}
h2, .h2 {
  font-size: 1.4rem;
}
h3, .h3 {
  font-size: 1.2rem;
}
h4, .h4 {
  font-size: 1.1rem;
}
h5, .h5 {
  font-size: 1rem;
}
h6, .h6 {
  font-size: 0.9rem;
}
h1.headline, .h1.headline {
  font-size: 3.8rem; 
  letter-spacing: -2.5px;
}
h2.headline, .h2.headline {
  font-size: 3rem; 
  letter-spacing: -2px; 
}
h3.headline, .h3.headline {
  font-size: 2.6rem;
  letter-spacing: -2px;
}
h4.headline, .h4.headline {
  font-size: 2.4rem;
  letter-spacing: -1.5px; 
}
h5.headline, .h5.headline {
  font-size: 2.2rem;
  letter-spacing: -1.4px; 
}
h6.headline, .h6.headline {
  font-size: 2rem;
  letter-spacing: -1.3px;
}
.text-size-12, .text-l-size-12 {
  font-size: 12px !important;
  line-height: 1.4;
}
.text-size-16, .text-l-size-16 {
  font-size: 16px !important;
  line-height: 1.4;
}
.text-size-20, .text-l-size-20 {
  font-size: 20px !important;
  line-height: 1.4;
}
.text-size-25, .text-l-size-25 {
  font-size: 25px !important;
  line-height: 1.4;
}
.text-size-30, .text-l-size-30 {
  font-size: 30px !important;
  line-height: 1.4;
}
.text-size-40, .text-l-size-40 {
  font-size: 40px !important;
  line-height: 1.4;
}
.text-size-50, .text-l-size-50 {
  font-size: 50px !important;
  line-height: 1.4;
}
.text-size-60, .text-l-size-60 {
  font-size: 60px !important;
  line-height: 1.4;
}
.text-size-70, .text-l-size-70 {
  font-size: 70px !important;
  line-height: 1.4;
} 
.text-center {
  text-align: center;
}
.text-right {
  text-align: right;
}
.text-thin {
  font-weight: 300;
}
b, strong, .text-strong {
  font-weight: 700;
}
.text-extra-strong {
  font-weight: 800;
}
blockquote::before {
  color: #e0e0e0;
  content: "“";
  display: block;
  float: left;
  font-family: georgia;
  font-size: 80px;
  height: 30px;
  left: -40px;
  position: relative;
  top: -20px;
  width: 0;
}
blockquote {
  border: 0;
  font-size: 1rem;
  padding: 0 0 0 40px;
}
a.text-tag:link {
  border: 1px solid #e5e5e5;
  display: inline-block;
  float: left;
  font-size: 0.75rem;
  margin: 1px 2px 1px 0;
  padding: 6px 9px;
}
a.text-tag:link:hover {
  background: #002633 none repeat scroll 0 0;
  border: 1px solid #002633;
  color: #fff;
  transition: all 0.20s linear 0s;
  -o-transition: all 0.20s linear 0s;
  -ms-transition: all 0.20s linear 0s;
  -moz-transition: all 0.20s linear 0s;
  -webkit-transition: all 0.20s linear 0s;
}

ul.text-list, ol.text-list {
  font-size: 0.85rem;
  line-height: 1.8rem;
  padding: 0 16px;
}
ul.text-list ul, ol.text-list ol {
  padding: 0 14px;
}
iframe {
  display: block;
  margin: 0;
}

/* Drop Cap */
.text-drop-cap {
  float: left;
  font-size: 65px;
  line-height: 45px;
  padding-right: 10px;
  padding-top: 5px;
}

/* Tables */
table {
	background:none repeat scroll 0 0 #fff;
	border:0;
	font-size: 0.85rem;
  line-height: 1.6rem;
	}
table tr td, table tr th {padding:10px;}
table tfoot, table thead {
  background:none repeat scroll 0 0 #f5f5f5;
  border-top:1px solid #f0f0f0;
  border-bottom:1px solid #f0f0f0;
}
table tr:nth-of-type(2n) {
  background:none repeat scroll 0 0 #f5f5f5;
  border-top:1px solid #f0f0f0;
  border-bottom:1px solid #f0f0f0;
}
th {border-right:1px solid #fff;}
td {border-right:1px solid #fff;}


/* Backgrounds */
.background-white-hightlight .top-nav .active-item > a, .background-white-hightlight .top-nav li a:hover, .background-white-hightlight .aside-nav li a:hover, 
.background-white-hightlight .aside-nav > ul > li.active-item > a:link, .background-white-hightlight .aside-nav > ul > li.active-item > a:visited,
.primary-color-white .background-primary-hightlight .top-nav .active-item > a, .primary-color-white .background-primary-hightlight .top-nav li a:hover, .primary-color-white .background-primary-hightlight .aside-nav li a:hover, 
.primary-color-white .background-primary-hightlight .aside-nav > ul > li.active-item > a:link, .primary-color-white .background-primary-hightlight .aside-nav > ul > li.active-item > a:visited {
  background: #fff none repeat scroll 0 0;
  color: #002633;
}

.background-primary-hightlight .top-nav .active-item > a, .background-primary-hightlight .top-nav li a:hover, .background-primary-hightlight .aside-nav li a:hover, 
.background-primary-hightlight .aside-nav > ul > li.active-item > a:link, .background-primary-hightlight .aside-nav > ul > li.active-item > a:visited,
.primary-color-primary .background-primary-hightlight .top-nav .active-item > a, .primary-color-primary .background-primary-hightlight .top-nav li a:hover, .primary-color-primary .background-primary-hightlight .aside-nav li a:hover, 
.primary-color-primary .background-primary-hightlight .aside-nav > ul > li.active-item > a:link, .primary-color-primary .background-primary-hightlight .aside-nav > ul > li.active-item > a:visited {
  background: #C81010 none repeat scroll 0 0;
  color: #fff;
}
.background-dark-hightlight .top-nav .active-item > a, .background-dark-hightlight .top-nav li a:hover, .background-dark-hightlight .aside-nav li a:hover, 
.background-dark-hightlight .aside-nav > ul > li.active-item > a:link, .background-dark-hightlight .aside-nav > ul > li.active-item > a:visited,
.primary-color-dark .background-primary-hightlight .top-nav .active-item > a, .primary-color-dark .background-primary-hightlight .top-nav li a:hover, .primary-color-dark .background-primary-hightlight .aside-nav li a:hover, 
.primary-color-dark .background-primary-hightlight .aside-nav > ul > li.active-item > a:link, .primary-color-dark .background-primary-hightlight .aside-nav > ul > li.active-item > a:visited {
  background: #002633 none repeat scroll 0 0;
  color: #fff;
}
.background-none {
  background: rgba(0, 0, 0, 0) none repeat scroll 0 0!important;
  border: 0;
}

/* Breaks */
hr.break {
  border: 0;
  border-top: 1px solid #e5e5e5; 
  display: block;
  margin: 40px 0;
}
hr.break:after {
clear:both;
content:".";
display:block;
height:0;
line-height:0;
visibility:hidden;
}
hr.break.break-dashed {
  border-top: 1px dashed #e5e5e5;
}
hr.break.break-dotted {
  border-top: 1px dotted #e5e5e5;
}
hr.break.break-double {
  border-bottom: 1px solid #e5e5e5;
  border-top: 1px solid #e5e5e5;
  height: 8px;
}
hr.break.break-dashed-double {
  border-bottom: 1px dashed #e5e5e5;
  border-top: 1px dashed #e5e5e5;
  height: 8px;
}
hr.break.break-dotted-double {
  border-bottom: 1px dotted #e5e5e5;
  border-top: 1px dotted #e5e5e5;
  height: 8px;
}

/* Small Breaks */
hr.break-small {
  background: #e5e5e5;
  border: 0;
  display: block;
  height: 2px;
  margin: 20px 0 35px;
  width: 60px;
}
hr.break-small.break-center {
  margin: 20px auto 35px;
}
hr.break-small.break-double {
  height: 0; 
  margin-bottom: 39px;
}
hr.break-small.break-double:before {
  background: #e5e5e5;
  border: 0 none;
  content: "";
  display: block;
  height: 2px;
  margin: 5px 0 0;
  width: 60px;
}
hr.break.break-small.break-double:after {
  background: #e5e5e5;
  border: 0 none;
  content: "";
  display: block;
  height: 2px;
  margin: 4px 0 35px;
  width: 60px;
}
hr.break-small.break-center.break-double:before {
  margin: 5px auto 0;
}
hr.break.break-small.break-center.break-double:after {
  margin: 4px auto 35px;
}
hr.break-small.break-double.background-white:before, hr.break-small.break-double.background-white:after, 
.primary-color-white hr.break-small.break-double.background-primary:before, .primary-color-white hr.break-small.break-double.background-primary:after {
  background: #fff;
}
hr.break-small.break-double.background-primary:before, hr.break-small.break-double.background-primary:after,
.primary-color-primary hr.break-small.break-double.background-primary:before, .primary-color-primary hr.break-small.break-double.background-primary:after {
  background: #C81010;
}


video {
  display: block;
} 

/* Top Nav */
.top-nav li a, .background-white .top-nav li a {
  color: #002633;
  font-size: 0.85rem;
  padding: 0.7em 1.25em;
}
nav {
  border-bottom: 4px solid rgba(0, 0, 0, 0.05);
  border-top: 1px solid rgba(0, 0, 0, 0.05);
  padding: 1.7rem 0;
  position: relative;
  z-index: 2;
}  
.top-nav ul ul {
  background: #002633 none repeat scroll 0 0;
}
.top-nav li ul li {
  border-bottom: 1px solid rgba(255, 255, 255, 0.05);
}
.top-nav li ul li:last-child {
  border-bottom: 0;
}
.top-nav li ul li a, .background-white .top-nav li ul li a, .top-nav .active-item li a {
  background: #002633 none repeat scroll 0 0;
  color: rgba(255,255,255, 0.75);
}
ul.chevron .submenu > a::after, ul.chevron .sub-submenu > a::after, ul.chevron .aside-submenu > a::after, ul.chevron .aside-sub-submenu > a::after {
  margin: 0 0 0 0.625rem;
}
.top-nav ul ul a {
  color: #eee;
}
.sticky {
  transition: all 0.20s linear 0s;
  -o-transition: all 0.20s linear 0s;
  -ms-transition: all 0.20s linear 0s;
  -moz-transition: all 0.20s linear 0s;
  -webkit-transition: all 0.20s linear 0s;
}
.fixed {
  left: 0;
  position: fixed;
  right: 0;
  top: 0;
  width: 100%;
  z-index: 10;
}
nav.fixed, .fixed nav {
  padding: 1rem 0;
}
.logo img {
  margin: 0 auto;
  max-width: 300px;
  width: 100%;
}

/* Aside Nav */
aside {
  border-left: 1px solid #e5e5e5;
  padding-left: 1.25rem;
}

.aside-nav ul {
  background: rgba(0, 0, 0, 0) none repeat scroll 0 0;
  margin-left: -1.25rem;
}
.aside-nav ul ul {
  margin: 0;
}
.aside-nav li a, .aside-nav li a:link, .aside-nav li a:visited {
  border-bottom: medium none;
  font-size: 0.85rem;
  padding: 15px;
  border-left: 5px solid rgba(0,0,0,0);
}
.aside-nav > ul > li > a:hover, .aside-nav > ul > li.active-item > a:link, .aside-nav > ul > li.active-item > a:visited {
  border-style: solid;
  border-width: 0 0 0 5px;
  border-color: #e5e5e5;
  background: none;
  color: #333;
}
.aside-nav li ul ul {
  background: #e9e9e9 none repeat scroll 0 0;
}
aside.aside-left {
  border-left: 0;
  border-right: 1px solid #e5e5e5;
  padding-right: 1.25rem;
}
.aside-left .aside-nav ul {
  margin-right: -1.25rem;
}
.aside-left .aside-nav li a {
  border-left: 0;
  border-right: 5px solid rgba(0,0,0,0);
}
.aside-left .aside-nav > ul > li > a:hover, .aside-left .aside-nav > ul > li.active-item > a:link, .aside-left .aside-nav > ul > li.active-item > a:visited {
  border-style: solid;
  border-width: 0 5px 0 0;
  border-color: #e5e5e5;
}

.aside-nav.background-white-hightlight > ul > li > a:hover, .aside-nav.background-white-hightlight > ul > li.active-item > a:link, .aside-nav.background-white-hightlight > ul > li.active-item > a:visited,
.primary-color-white .aside-nav.background-primary-hightlight > ul > li > a:hover, .primary-color-white .aside-nav.background-primary-hightlight > ul > li.active-item > a:link, .primary-color-white .aside-nav.background-primary-hightlight > ul > li.active-item > a:visited {
  border-color: #fff;
} 

.aside-nav.background-primary-hightlight > ul > li > a:hover, .aside-nav.background-primary-hightlight > ul > li.active-item > a:link, .aside-nav.background-primary-hightlight > ul > li.active-item > a:visited,
.primary-color-primary .aside-nav.background-primary-hightlight > ul > li > a:hover, .primary-color-primary .aside-nav.background-primary-hightlight > ul > li.active-item > a:link, .primary-color-primary .aside-nav.background-primary-hightlight > ul > li.active-item > a:visited {
  border-color: #C81010;
}  
.aside-nav.background-dark-hightlight > ul > li > a:hover, .aside-nav.background-dark-hightlight > ul > li.active-item > a:link, .aside-nav.background-dark-hightlight > ul > li.active-item > a:visited,
.primary-color-dark .aside-nav.background-primary-hightlight > ul > li > a:hover, .primary-color-dark .aside-nav.background-primary-hightlight > ul > li.active-item > a:link, .primary-color-dark .aside-nav.background-primary-hightlight > ul > li.active-item > a:visited {
  border-color: #002633;
}

/* Font colors */
.background-white, .background-white p, a.background-white, .background-white a, .background-white a:link, .background-white a:visited, .background-white a:hover, .background-white a:active {
  color: #777;
} 
.background-dark, .background-dark p, a.background-dark, a.background-dark:visited, a.background-dark:link, .background-dark a, .background-dark a:link, .background-dark a:visited, .background-dark a:hover, .background-dark a:active,
.primary-color-dark .background-primary, .primary-color-dark .background-primary p, .primary-color-dark a.background-primary, .primary-color-dark a.background-primary:visited, .primary-color-dark a.background-primary:link, .primary-color-dark a.background-primary:visited, .primary-color-dark .background-primary a, .primary-color-dark .background-primary a:link, .primary-color-dark .background-primary a:visited, .primary-color-dark .background-primary a:hover, .primary-color-dark .background-primary a:active {
  color: #7697A2;
}
.background-white h1, .background-white h2, .background-white h3, .background-white h4, .background-white h5, .background-white h6,
.background-white .h1, .background-white .h2, .background-white .h3, .background-white .h4, .background-white .h5, .background-white .h6, 
.primary-color-white .background-primary h1, .primary-color-white .background-primary h2, .primary-color-white .background-primary h3, .primary-color-white .background-primary h4, .primary-color-white .background-primary h5, .primary-color-white .background-primary h6,
.primary-color-white .background-primary .h1, .primary-color-white .background-primary .h2, .primary-color-white .background-primary .h3, .primary-color-white .background-primary .h4, .primary-color-white .background-primary .h5, .primary-color-white .background-primary .h6 {
  color: #002633;
} 
.image-hover-overlay-content *,
.background-primary, .background-primary p, a.background-primary, a.background-primary:visited, a.background-primary:link, .background-primary a, .background-primary a:link, .background-primary a:visited, .background-primary a:hover, .background-primary a:active,
.primary-color-primary .background-primary, .primary-color-primary .background-primary p, .primary-color-primary a.background-primary, .primary-color-primary a.background-primary:visited, .primary-color-primary a.background-primary:link, .primary-color-primary .background-primary a, .primary-color-primary .background-primary a:link, .primary-color-primary .background-primary a:visited, .primary-color-primary .background-primary a:hover, .primary-color-primary .background-primary a:active {
  color: rgba(255,255,255, 0.75);
}
.background-dark h1, .background-dark h2, .background-dark h3, .background-dark h4, .background-dark h5, .background-dark h6,
.background-dark .h1, .background-dark .h2, .background-dark .h3, .background-dark .h4, .background-dark .h5, .background-dark .h6, 
.primary-color-dark .background-primary h1, .primary-color-dark .background-primary h2, .primary-color-dark .background-primary h3, .primary-color-dark .background-primary h4, .primary-color-dark .background-primary h5, .primary-color-dark .background-primary h6,
.primary-color-dark .background-primary .h1, .primary-color-dark .background-primary .h2, .primary-color-dark .background-primary .h3, .primary-color-dark .background-primary .h4, .primary-color-dark .background-primary .h5, .primary-color-dark .background-primary .h6, 
.background-primary h1, .background-primary h2, .background-primary h3, .background-primary h4, .background-primary h5, .background-primary h6,
.background-primary .h1, .background-primary .h2, .background-primary .h3, .background-primary .h4, .background-primary .h5, .background-primary .h6,
.primary-color-primary .background-primary h1, .primary-color-primary .background-primary h2, .primary-color-primary .background-primary h3, .primary-color-primary .background-primary h4, .primary-color-primary .background-primary h5, .primary-color-primary .background-primary h6,
.primary-color-primary .background-primary .h1, .primary-color-primary .background-primary .h2, .primary-color-primary .background-primary .h3, .primary-color-primary .background-primary .h4, .primary-color-primary .background-primary .h5, .primary-color-primary .background-primary .h6 {
  color: #fff;
}
.text-white, .text-white *, .primary-color-white .text-primary, .primary-color-white .text-primary * {
  color: #fff !important;
}
.text-primary, .text-primary *, .primary-color-primary .text-primary, .primary-color-primary .text-primary * {
  color: #C81010 !important;
}
.text-dark, .text-dark *, .primary-color-dark .text-primary, .primary-color-dark .text-primary * {
  color: #002633 !important;
} 
.text-white-hover, .text-primary-hover, .text-dark-hover {
  transition: color 0.20s linear 0s;
  -o-transition: color 0.20s linear 0s;
  -ms-transition: color 0.20s linear 0s;
  -moz-transition: color 0.20s linear 0s;
  -webkit-transition: color 0.20s linear 0s;
}
.text-white-hover:hover, .primary-color-white .text-primary-hover:hover {
  color: #fff !important;
}
.text-primary-hover:hover, .primary-color-primary .text-primary-hover:hover {
  color: #C81010 !important;
}
.text-dark-hover:hover, .primary-color-dark .text-primary-hover:hover {
  color: #002633 !important;
} 

/* Background Colors */
.background-white, .primary-color-white .background-primary {
  background-color: #fff !important;
}
.background-primary, .primary-color-primary .background-primary {
  background-color: #1d113b !important;
}
.background-dark, .primary-color-dark .background-primary {
  background-color: #002633 !important; 
}
/* Background Opacity */
.background-white.background-transparent, .primary-color-white .background-primary.background-transparent {
  background-color: rgba(255, 255, 255, 0.85) !important;
}
.background-primary.background-transparent, .primary-color-primary .background-primary.background-transparent {
  background-color: rgba(200, 16, 16, 0.85) !important;
}
.background-dark.background-transparent, .primary-color-dark .background-primary.background-transparent {
  background-color: rgba(0, 38, 51, 0.85) !important;
}


/* Hover Overlay */
.image-hover-overlay {
  bottom: 0;
  color: rgba(255,255,255, 0.75)!important;
  left: 0;
  opacity: 0;
  padding: 1.25rem;
  position: absolute;
  right: 0;
  top: 0;
  z-index: 1;
  transition: all 0.20s linear 0s;
  -o-transition: all 0.20s linear 0s;
  -ms-transition: all 0.20s linear 0s;
  -moz-transition: all 0.20s linear 0s;
  -webkit-transition: all 0.20s linear 0s;
  transform-style: preserve-3d;
  -o-transform-style: preserve-3d;
  -ms-transform-style: preserve-3d;
  -moz-transform-style: preserve-3d;
  -webkit-transform-style: preserve-3d;
}
.image-border-radius .image-hover-overlay {
  border-radius: 3px;
}
.image-hover-overlay:hover {
  opacity: 1;
}
.image-hover-overlay-content {
  position: absolute;
  left: 0;
  right: 0;
  top: 60%;
  transition: all 0.20s linear 0s;
  -o-transition: all 0.20s linear 0s;
  -ms-transition: all 0.20s linear 0s;
  -moz-transition: all 0.20s linear 0s;
  -webkit-transition: all 0.20s linear 0s;
  transform: translateY(-50%);
  -o-transform: translateY(-50%);
  -ms-transform: translateY(-50%);
  -moz-transform: translateY(-50%);
  -webkit-transform: translateY(-50%);
}
.image-hover-overlay:hover > .image-hover-overlay-content {
  top: 50%;
}

/* Image blocks */
.image-with-hover-overlay {
  display: block;
  position: relative;
}
.image-border-radius img {
  border-radius: 3px;
}
.image-hover-zoom {
  display: block;
  overflow: hidden;
}
.image-hover-zoom img {
  transition: all 0.20s linear 0s;
  -o-transition: all 0.20s linear 0s;
  -ms-transition: all 0.20s linear 0s;
  -moz-transition: all 0.20s linear 0s;
  -webkit-transition: all 0.20s linear 0s;
}
.image-with-hover-overlay img {
  width: 100%;
}
.image-hover-zoom:hover img {
  transform: scale(1.1);
}


/* Buttons */
.button, a.button, a.button:link, a.button:visited {
  border-color: rgba(255, 255, 255, 0.4) rgba(255, 255, 255, 0) rgba(0, 0, 0, 0.3);
  border-style: solid;
  border-width: 1px;
  color: white;
  display: inline-block;
  padding: 0.625rem 1.25rem;
  text-align: center;
  transition: all 0.20s linear 0s !important;
  -o-transition: all 0.20s linear 0s !important;
  -ms-transition: all 0.20s linear 0s !important;
  -moz-transition: all 0.20s linear 0s !important;
  -webkit-transition: all 0.20s linear 0s !important;
}

.button:hover, a.button:hover, a.button:link:hover, a.button:visited:hover {
  box-shadow: 0 0 100px 100px rgba(255, 255, 255, 0.25) inset;
}
/* Stroke Buttons */ 
.button.button-white-stroke, a.button.button-white-stroke, a.button.button-white-stroke:link, a.button.button-white-stroke:visited,
.primary-color-white .button.button-primary-stroke, .primary-color-white a.button.button-primary-stroke, .primary-color-white a.button.button-primary-stroke:link, .primary-color-white a.button.button-primary-stroke:visited {
  background: none;
  border: 1px solid #fff;
  box-shadow: none;
}
.button.button-white-stroke:hover, a.button.button-white-stroke:hover,
.primary-color-white .button.button-primary-stroke:hover, .primary-color-white a.button.button-primary-stroke:hover {
  background: #fff none repeat scroll 0 0;
  color: #002633;
}
.button.button-primary-stroke, a.button.button-primary-stroke, a.button.button-primary-stroke:link, a.button.button-primary-stroke:visited,
.primary-color-primary .button.button-primary-stroke, .primary-color-primary a.button.button-primary-stroke, .primary-color-primary a.button.button-primary-stroke:link, .primary-color-primary a.button.button-primary-stroke:visited {
  background: none;
  border: 1px solid #C81010;
  box-shadow: none;
  color: #C81010;
}
.button.button-primary-stroke:hover, a.button.button-primary-stroke:hover,
.primary-color-primary .button.button-primary-stroke:hover, .primary-color-primary a.button.button-primary-stroke:hover {
  background: #C81010 none repeat scroll 0 0;
  color: #fff;
}

.button.button-dark-stroke, a.button.button-dark-stroke, a.button.button-dark-stroke:link, a.button.button-dark-stroke:visited,
.primary-color-dark .button.button-primary-stroke, .primary-color-dark a.button.button-primary-stroke, .primary-color-dark a.button.button-primary-stroke:link, .primary-color-dark a.button.button-primary-stroke:visited {
  background: none;
  border: 1px solid #002633;
  box-shadow: none;
  color: #002633;
}
.button.button-dark-stroke:hover, a.button.button-dark-stroke:hover,
.primary-color-dark .button.button-primary-stroke:hover, .primary-color-dark a.button.button-primary-stroke:hover {
  background: #002633 none repeat scroll 0 0;
  color: #fff;
}

/* Containers */
.section  { 
  padding: 6rem 1.25rem;
}
.section-small-padding  { 
  padding: 2.5rem 1.25rem;
}
.section-top-padding  { 
  padding-top: 6rem;
}
.section-top-small-padding  { 
  padding-top: 2.5rem;
}
.float-left {
  float: left;
}
.block-bordered {
  border: 1px solid rgba(0, 0, 0, 0.1);
}
.padding {
  padding: 1.25rem!important;
}
.padding-2x {
  padding: 2.5rem!important;
}
.full-width:after {
  clear:both;
  content:".";
  display:block;
  height:0;
  line-height:0;
  visibility:hidden;
}
.full-width > .line {
    padding: 0 1.875rem;
}
.position-fixed  { 
  position: fixed;
  top: 0;
  width: 100%;
}
.center {
  display: block!important;
}
.border-radius  { 
  border-radius: 3px;
}
.content-center-vertical {
  position: absolute;
  left: 0;
  right: 0;
  top: 50%; 
  transform: translateY(-50%);
  -o-transform: translateY(-50%);
  -ms-transform: translateY(-50%);
  -moz-transform: translateY(-50%);
  -webkit-transform:translateY(-50%);
}
.content-bottom {
  bottom: 0;
  position: absolute;
}
.grayscale {
  filter: url('data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg"><filter id="g"><feColorMatrix type="matrix" values="0.3 0.3 0.3 0 0 0.3 0.3 0.3 0 0 0.3 0.3 0.3 0 0 0 0 0 1 0"/></filter></svg>#g');
  -webkit-filter: grayscale(100%);
  filter: grayscale(100%);    
  filter: progid:DXImageTransform.Microsoft.BasicImage(grayScale=1);
}

.image-grayscale {
  filter: url('data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg"><filter id="g"><feColorMatrix type="matrix" values="0.3 0.3 0.3 0 0 0.3 0.3 0.3 0 0 0.3 0.3 0.3 0 0 0 0 0 1 0"/></filter></svg>#g');
  -webkit-filter: grayscale(100%);
  filter: grayscale(100%);    
  filter: progid:DXImageTransform.Microsoft.BasicImage(grayScale=1);
  position: relative;
}
*:hover > .image-grayscale {
  filter: none;
  -webkit-filter: grayscale(0%);
  filter: grayscale(0%);    
  filter: progid:DXImageTransform.Microsoft.BasicImage(grayScale=0);
}


/* Margins */
.margin-top {
  margin-top: 1.25rem !important;
}
.margin-left {
  margin-left: 1.25rem !important;
}
.margin-right {
  margin-right: 1.25rem !important;
}
.margin-top-bottom {
  margin-top: 1.25rem !important;
  margin-bottom: 1.25rem !important;
}
.margin-left-right {
  margin-left: 1.25rem !important;
  margin-right: 1.25rem !important;
}
.margin-top-0 {
  margin-top: 0 !important;
  display: block;
}
.margin-top-10 {
  margin-top: 10px !important;
  display: block;
}
.margin-top-15 {
  margin-top: 15px !important;
  display: block;
} 
.margin-top-20 {
  margin-top: 20px !important;
  display: block;
} 
.margin-top-30 {
  margin-top: 30px !important;
  display: block;
} 
.margin-top-40 {
  margin-top: 40px !important;
  display: block;
}
.margin-top-50 {
  margin-top: 50px !important;
  display: block;
}
.margin-top-60 {
  margin-top: 60px !important;
  display: block;
}
.margin-top-70 {
  margin-top: 70px !important;
  display: block;
}
.margin-top-80 {
  margin-top: 80px !important;
  display: block;
}
.margin-bottom-0 {
  margin-bottom: 0 !important;
  display: block;
}
.margin-bottom-10 {
  margin-bottom: 10px !important;
  display: block;
}
.margin-bottom-15 {
  margin-bottom: 15px !important;
  display: block;
} 
.margin-bottom-20 {
  margin-bottom: 20px !important;
  display: block;
} 
.margin-bottom-30 {
  margin-bottom: 30px !important;
  display: block;
} 
.margin-bottom-40 {
  margin-bottom: 40px !important;
  display: block;
}
.margin-bottom-50 {
  margin-bottom: 50px !important;
  display: block;
}
.margin-bottom-60 {
  margin-bottom: 60px !important;
  display: block;
}
.margin-bottom-70 {
  margin-bottom: 70px !important;
  display: block;
}
.margin-bottom-80 {
  margin-bottom: 80px !important;
  display: block;
}
.margin-top-bottom-0 {
  margin-top: 0 !important;
  margin-bottom: 0 !important;
  display: block;
}
.margin-top-bottom-10 {
  margin-top: 10px !important;
  margin-bottom: 10px !important;
  display: block;
}
.margin-top-bottom-15 {
  margin-top: 15px !important;
  margin-bottom: 15px !important;
  display: block;
} 
.margin-top-bottom-20 {
  margin-top: 20px !important;
  margin-bottom: 20px !important;
  display: block;
} 
.margin-top-bottom-30 {
  margin-top: 30px !important;
  margin-bottom: 30px !important;
  display: block;
} 
.margin-top-bottom-40 {
  margin-top: 40px !important;
  margin-bottom: 40px !important;
  display: block;
}
.margin-top-bottom-50 {
  margin-top: 50px !important;
  margin-bottom: 50px !important;
  display: block;
}
.margin-top-bottom-60 {
  margin-top: 60px !important;
  margin-bottom: 60px !important;
  display: block;
} 
.margin-top-bottom-70 {
  margin-top: 70px !important;
  margin-bottom: 70px !important;
  display: block;
} 
.margin-top-bottom-80 {
  margin-top: 80px !important;
  margin-bottom: 80px !important;
  display: block;
}

.margin-left-0 {
  margin-left: 0 !important;
}
.margin-left-10 {
  margin-left: 10px !important;
}
.margin-left-15 {
  margin-left: 15px !important;
} 
.margin-left-20 {
  margin-left: 20px !important;
} 
.margin-left-30 {
  margin-left: 30px !important;
} 
.margin-left-40 {
  margin-left: 40px !important;
}
.margin-left-50 {
  margin-left: 50px !important;
}
.margin-left-60 {
  margin-left: 60px !important;
}
.margin-left-70 {
  margin-left: 70px !important;
}
.margin-left-80 {
  margin-left: 80px !important;
}
.margin-right-0 {
  margin-right: 0 !important;
}
.margin-right-10 {
  margin-right: 10px !important;
}
.margin-right-15 {
  margin-right: 15px !important;
} 
.margin-right-20 {
  margin-right: 20px !important;
} 
.margin-right-30 {
  margin-right: 30px !important;
} 
.margin-right-40 {
  margin-right: 40px !important;
}
.margin-right-50 {
  margin-right: 50px !important;
}
.margin-right-60 {
  margin-right: 60px !important;
}
.margin-right-70 {
  margin-right: 70px !important;
}
.margin-right-80 {
  margin-right: 80px !important;
}
.margin-left-right-0 {
  margin-left: 0 !important;
  margin-right: 0 !important;
}
.margin-left-right-10 {
  margin-left: 10px !important;
  margin-right: 10px !important;
}
.margin-left-right-15 {
  margin-left: 15px !important;
  margin-right: 15px !important;
} 
.margin-left-right-20 {
  margin-left: 20px !important;
  margin-right: 20px !important;
} 
.margin-left-right-30 {
  margin-left: 30px !important;
  margin-right: 30px !important;
} 
.margin-left-right-40 {
  margin-left: 40px !important;
  margin-right: 40px !important;
}
.margin-left-right-50 {
  margin-left: 50px !important;
  margin-right: 50px !important;
}
.margin-left-right-60 {
  margin-left: 60px !important;
  margin-right: 60px !important;
} 
.margin-left-right-70 {
  margin-left: 70px !important;
  margin-right: 70px !important;
} 
.margin-left-right-80 {
  margin-left: 80px !important;
  margin-right: 80px !important;
}        

/* More info button */
a.text-more-info {
  display: block;
  font-size: 0.85rem;
  margin-top: 0.625rem;
}
a.text-more-info:after {
  content: "\f006";
  font-family: mfg;
  font-size: 0.8rem;
  margin-left: 0.625rem;
  transition: all 0.20s linear 0s;
-o-transition: all 0.20s linear 0s;
-ms-transition: all 0.20s linear 0s;
-moz-transition: all 0.20s linear 0s;
-webkit-transition: all 0.20s linear 0s;
}
a.text-more-info:hover:after {
  margin-left: 0.825rem;
}

/* Top bar */
.top-bar-contact p {
  height: 35px;
  line-height: 35px;
}
.top-bar-social li {
  border-left: 1px solid rgba(0,0,0, 0.05);
  float: left;
  height: 35px;
  line-height: 35px;
  list-style: outside none none;
  text-align: center;
  width: 35px;
}
.top-bar-social li:last-child {
  border-right: 1px solid rgba(0,0,0, 0.05);
}
.top-bar-social i {
  color: rgba(170, 170, 170, 0.20);
  font-size: 18px; 
}

/* Icon blocks */
i.icon-circle {
  border-radius: 100px;
  display: block;
  height: 100px;
  line-height: 100px;
  margin-bottom: 0.625rem;
  text-align: center;
  width: 100px;
}
i.icon-circle-small {
  border-radius: 60px;
  display: block;
  font-size: 1.1rem;
  height: 60px;
  line-height: 60px;
  margin-bottom: 0.625rem;
  text-align: center;
  width: 60px;
}

/* Carousel */
/*.owl-theme .owl-controls {
  margin-top: 0;
}*/
.owl-carousel .owl-nav div {
  filter: Alpha(Opacity=50);
  opacity: 0.5;
  transition: all 0.20s linear 0s;
  -o-transition: all 0.20s linear 0s;
  -ms-transition: all 0.20s linear 0s;
  -moz-transition: all 0.20s linear 0s;
  -webkit-transition: all 0.20s linear 0s;
}
.owl-carousel .owl-nav div:hover {
  filter: Alpha(Opacity=100);
  opacity: 1;
}
.owl-carousel .owl-dots {
  text-align: center;
}
.owl-carousel .owl-dot {
  display: inline-block;
}
.owl-carousel .owl-dot span {
  background: #7697a2 none repeat scroll 0 0;
  border-radius: 0;
  display: block;
  height: 1px;
  margin: 0 1px;
  width: 30px;
  filter: Alpha(Opacity=50);
  opacity: 0.5;
  transition: all 0.20s linear 0s;
  -o-transition: all 0.20s linear 0s;
  -ms-transition: all 0.20s linear 0s;
  -moz-transition: all 0.20s linear 0s;
  -webkit-transition: all 0.20s linear 0s;
}
.owl-carousel .owl-dot.active span {
  filter: Alpha(Opacity=100);
  opacity: 1;
}
.owl-carousel .owl-nav div {
  background: rgba(0, 0, 0, 0) none repeat scroll 0 0;
  color: #7697a2!important;
  border: 1px solid #7697a2;
  border-radius: 0;
  font-family: sli;
  height: 40px;
  line-height: 40px;
  margin-top: -20px;
  padding: 0;
  position: absolute;
  text-align: center;
  top: 50%;    
  width: 40px;
}
.carousel-bottom-arrows.owl-carousel .owl-nav div {
  bottom: 0;
  top: auto;
}
.owl-carousel .owl-nav .owl-prev {
  left: 0;    
}
.owl-carousel .owl-nav .owl-next {
  right: 0;
}
.carousel-wide-arrows.owl-carousel .owl-nav .owl-prev {
  left: -60px;
}
.carousel-wide-arrows.owl-carousel .owl-nav .owl-next {
  right: -60px;
}
.carousel-nav-white.owl-carousel .owl-dots span {
  background: #fff none repeat scroll 0 0;
}
.carousel-nav-white.owl-carousel .owl-nav div {
  color: #fff!important;
  border: 1px solid #fff;
}
.carousel-main .carousel-content {
  bottom: 0;
  position: absolute;
  top: 0;
  width: 100%;
  z-index: 1;
  transform-style: preserve-3d;
  -o-transform-style: preserve-3d;
  -ms-transform-style: preserve-3d;
  -moz-transform-style: preserve-3d;
  -webkit-transform-style: preserve-3d;
}
.owl-dots {
  margin-top: 0.625rem;
} 
.carousel-main .owl-dots {
  bottom: 0;
  padding: 1.25rem 0;
  position: absolute;
  width: 100%;
}
.carousel-blocks {
  padding: 0 3rem;
}
.carousel-blocks .owl-item {
  padding: 0 0.625rem;
}
.carousel-hide-arrows .owl-nav, .carousel-hide-pagination .owl-pagination {
display:none;
}
.carousel-3-blocks {
  padding: 0 3rem;
}
.carousel-3-blocks .owl-item {
  padding: 0 0.625rem;
}

/* Portfolio Tabs */
.tab-nav.line {
  display: table;
  padding-bottom: 1.25rem;
}
.tab-item {
  padding: 0;
}
a.tab-label, a.tab-label:link, a.tab-label:visited,
.background-white a.tab-label, .background-white a.tab-label:link, .background-white a.tab-label:visited, .background-white a.tab-label:hover {
  background: #002633 none repeat scroll 0 0;
  color: rgba(255,255,255, 0.75);
}
a.tab-label, a.tab-label:link, a.tab-label:visited, a.tab-label:hover,
.background-white a.tab-label, .background-white a.tab-label:link, .background-white a.tab-label:visited, .background-white a.tab-label:hover {
  background: rgba(0, 0, 0, 0) none repeat scroll 0 0;
  color: #002633;
}
.background-white-hightlight a.tab-label.active-btn, .background-white-hightlight a.tab-label:hover,
.primary-color-white .background-primary-hightlight a.tab-label.active-btn, .primary-color-white .background-primary-hightlight a.tab-label:hover {
  background: #fff none repeat scroll 0 0;
  color: #002633;
}
.background-primary-hightlight a.tab-label.active-btn, .background-primary-hightlight a.tab-label:hover,
.primary-color-primary .background-primary-hightlight a.tab-label.active-btn, .primary-color-primary .background-primary-hightlight a.tab-label:hover {
  background: #C81010 none repeat scroll 0 0;
  color: #fff;
}
.background-dark-hightlight a.tab-label.active-btn, .background-dark-hightlight a.tab-label:hover,
.primary-color-dark .background-primary-hightlight a.tab-label.active-btn, .primary-color-dark .background-primary-hightlight a.tab-label:hover {
  background: #002633 none repeat scroll 0 0;
  color: #fff;
}

/* Forms */
form.customform input, form.customform textarea, form.customform select {
  background: rgba(0, 0, 0, 0.03) none repeat scroll 0 0;
  border: 1px solid rgba(0, 0, 0, 0.14);
  font-size: 12px;
  padding: 0.625rem;
  width: 100%;
}
form.customform input:hover, form.customform textarea:hover, form.customform select:hover, form.customform input:focus, form.customform textarea:focus, form.customform select:focus {
  background: rgba(0, 0, 0, 0) none repeat scroll 0 0;
}
p.form-error {
  background-color: #DD442C;
  color: #fff;
  display: none;
  font-size: 0.8rem;
  margin: -10px 0 15px 0;
  padding: 7px;
  text-align: center;
}
p.form-success {
  background-color: #9bdd42;
  color: #fff;
  display: none;
  font-size: 0.85rem;
  padding: 10px;
  text-align: center;
}
.required {
  border-left: 1px solid #dd442c !important;
}


/* -1120px version */
@media screen and (max-width:1120px) {
  .size-1140 .line.content-center-vertical {
      padding: 0 2rem;
  }
}

/* -768px version */
@media screen and (max-width:768px) {
    .top-nav .right {
      float: none;
    }
    .logo {
      max-width: 250px;
      margin: 0 auto;
    }
    .nav-text {
      color: #fff;
      display: block;
      font-size: 1.2rem;
      line-height: 3rem;
      margin-right: 0.625rem;
      max-width: 100%;
      text-align: center;
      vertical-align: middle;
    }
    .nav-text::after {
      color: #002633;
      display: inline-block;
      font-size: 3rem;
      margin-left: 0;
      margin-top: 30px;
    }
    .top-nav li a, .background-white .top-nav li a {
      background: #002633 none repeat scroll 0 0;
      color: #fff;
      font-size: 1.1em;
      padding: 1em;
      text-align: center;
    }
    aside {
        border: none;
        padding: 0;
    }
    aside.aside-left {
        border-right: 0;
        padding-right: 0;
    }
    .owl-nav {
      display: none;
    }
    .carousel-main .owl-item img, .carousel-main .owl-item video {
      max-width: 250%;
    	width:auto;
    }
    .margin-m-top {
      margin-top: 1.25rem !important;
      display: block;
    }
    .margin-m-bottom {
        margin-bottom: 1.25rem !important;
        display: block;
    }
    .margin-m-left {
        margin-left: 1.25rem !important;
    }
    .margin-m-right {
        margin-right: 1.25rem !important;
    }
    .margin-m-top-bottom {
        margin-top: 1.25rem !important;
        margin-bottom: 1.25rem !important;
    display: block;
    }
    .margin-m-left-right {
        margin-left: 1.25rem !important;
        margin-right: 1.25rem !important;
    }
    .margin-m-top-0 {
        margin-top: 0 !important;
    display: block;
    }
    .margin-m-top-10 {
        margin-top: 10px !important; 
    display: block;
    }
    .margin-m-top-15 {
        margin-top: 15px !important;
    display: block;
    } 
    .margin-m-top-20 {
        margin-top: 20px !important; 
    display: block;
    } 
    .margin-m-top-30 {
        margin-top: 30px !important;
    display: block;
    } 
    .margin-m-top-40 {
        margin-top: 40px !important;
    display: block;
    }
    .margin-m-top-50 {
        margin-top: 50px !important;
    display: block;
    }
    .margin-m-top-60 {
        margin-top: 60px !important;
    display: block;
    }
    .margin-m-top-70 {
        margin-top: 70px !important; 
    display: block;
    }
    .margin-m-top-80 {
        margin-top: 80px !important;
    display: block;
    }
    .margin-m-bottom-0 {
        margin-bottom: 0 !important; 
    display: block;
    }
    .margin-m-bottom-10 {
        margin-bottom: 10px !important; 
    display: block;
    }
    .margin-m-bottom-15 {
        margin-bottom: 15px !important;
    display: block;
    } 
    .margin-m-bottom-20 {
        margin-bottom: 20px !important;
    display: block;
    } 
    .margin-m-bottom-30 {
        margin-bottom: 30px !important;
    display: block;
    } 
    .margin-m-bottom-40 {
        margin-bottom: 40px !important;
    display: block;
    }
    .margin-m-bottom-50 {
        margin-bottom: 50px !important;
    display: block;
    }
    .margin-m-bottom-60 {
        margin-bottom: 60px !important;
    display: block;
    }
    .margin-m-bottom-70 {
        margin-bottom: 70px !important;
    display: block;
    }
    .margin-m-bottom-80 {
        margin-bottom: 80px !important; 
    display: block;
    }
    .margin-m-top-bottom-0 {
        margin-top: 0 !important;
        margin-bottom: 0 !important;
    display: block;
    }
    .margin-m-top-bottom-10 {
        margin-top: 10px !important;
        margin-bottom: 10px !important;
    display: block;
    }
    .margin-m-top-bottom-15 {
        margin-top: 15px !important;
        margin-bottom: 15px !important; 
    display: block;
    } 
    .margin-m-top-bottom-20 {
        margin-top: 20px !important;
        margin-bottom: 20px !important; 
    display: block;
    } 
    .margin-m-top-bottom-30 {
        margin-top: 30px !important;
        margin-bottom: 30px !important; 
    display: block;
    } 
    .margin-m-top-bottom-40 {
        margin-top: 40px !important;
        margin-bottom: 40px !important; 
    display: block;
    }
    .margin-m-top-bottom-50 {
        margin-top: 50px !important;
        margin-bottom: 50px !important;
    display: block;
    }
    .margin-m-top-bottom-60 {
        margin-top: 60px !important;
        margin-bottom: 60px !important; 
    display: block;
    } 
    .margin-m-top-bottom-70 {
        margin-top: 70px !important;
        margin-bottom: 70px !important;
    display: block;
    } 
    .margin-m-top-bottom-80 {
        margin-top: 80px !important;
        margin-bottom: 80px !important;
    display: block;
    }
    
    .margin-m-left-0 {
        margin-left: 0 !important;
    }
    .margin-m-left-10 {
        margin-left: 10px !important;
    }
    .margin-m-left-15 {
        margin-left: 15px !important;
    } 
    .margin-m-left-20 {
        margin-left: 20px !important;
    } 
    .margin-m-left-30 {
        margin-left: 30px !important;
    } 
    .margin-m-left-40 {
        margin-left: 40px !important;
    }
    .margin-m-left-50 {
        margin-left: 50px !important;
    }
    .margin-m-left-60 {
        margin-left: 60px !important;
    }
    .margin-m-left-70 {
        margin-left: 70px !important;
    }
    .margin-m-left-80 {
        margin-left: 80px !important;
    }
    .margin-m-right-0 {
        margin-right: 0 !important;
    }
    .margin-m-right-10 {
        margin-right: 10px !important;
    }
    .margin-m-right-15 {
        margin-right: 15px !important;
    } 
    .margin-m-right-20 {
        margin-right: 20px !important;
    } 
    .margin-m-right-30 {
        margin-right: 30px !important;
    } 
    .margin-m-right-40 {
        margin-right: 40px !important;
    }
    .margin-m-right-50 {
        margin-right: 50px !important;
    }
    .margin-m-right-60 {
        margin-right: 60px !important;
    }
    .margin-m-right-70 {
        margin-right: 70px !important;
    }
    .margin-m-right-80 {
        margin-right: 80px !important;
    }
    .margin-m-left-right-0 {
        margin-left: 0 !important;
        margin-right: 0 !important;
    }
    .margin-m-left-right-10 {
        margin-left: 10px !important;
        margin-right: 10px !important;
    }
    .margin-m-left-right-15 {
        margin-left: 15px !important;
        margin-right: 15px !important;
    } 
    .margin-m-left-right-20 {
        margin-left: 20px !important;
        margin-right: 20px !important;
    } 
    .margin-m-left-right-30 {
        margin-left: 30px !important;
        margin-right: 30px !important;
    } 
    .margin-m-left-right-40 {
        margin-left: 40px !important;
        margin-right: 40px !important;
    }
    .margin-m-left-right-50 {
        margin-left: 50px !important;
        margin-right: 50px !important;
    }
    .margin-m-left-right-60 {
        margin-left: 60px !important;
        margin-right: 60px !important;
    } 
    .margin-m-left-right-70 {
        margin-left: 70px !important;
        margin-right: 70px !important;
    } 
    .margin-m-left-right-80 {
        margin-left: 80px !important;
        margin-right: 80px !important;
    }  
    .text-m-size-12 {
      font-size: 12px !important;
      line-height: 1.4;
    }
    .text-m-size-16 {
        font-size: 16px !important;
        line-height: 1.4;
    }
    .text-m-size-20 {
        font-size: 20px !important;
        line-height: 1.4;
    }
    .text-m-size-25 {
        font-size: 25px !important;
        line-height: 1.4;
    }
    .text-m-size-30 {
        font-size: 30px !important;
        line-height: 1.4;
    }
    .text-m-size-40 {
        font-size: 40px !important;
        line-height: 1.4;
    }
    .text-m-size-50 {
        font-size: 50px !important;
        line-height: 1.4;
    }
    .text-m-size-60 {
        font-size: 60px !important;
        line-height: 1.4;
    }
    .text-m-size-70 {
        font-size: 70px !important;
        line-height: 1.4;
    } 
    .owl-nav {
      display: none;
    }
}  

/* -480px version */
@media screen and (max-width:480px) {
    .top-bar .right {
      float: none;
    }
    .top-bar-contact p {
      height: auto;
      line-height: 1.3rem;
      padding: 10px 0;
      text-align: center;
    }
    .top-bar-social.right {
      display: table;
      float: none;
      margin: 0 auto;
      padding: 0;
      text-align: center;
    }
    .margin-s-top {
        margin-top: 1.25rem !important;
        display: block;
    }
    .margin-s-bottom {
        margin-bottom: 1.25rem !important; 
        display: block;
    }
    .margin-s-left {
        margin-left: 1.25rem !important;
    }
    .margin-s-right {
        margin-right: 1.25rem !important;
    }
    .margin-s-top-bottom {
        margin-top: 1.25rem !important;
        margin-bottom: 1.25rem !important;
        display: block;
    }
    .margin-s-left-right {
        margin-left: 1.25rem !important;
        margin-right: 1.25rem !important;
    }
    .margin-s-top-0 {
        margin-top: 0 !important; 
        display: block;
    }
    .margin-s-top-10 {
        margin-top: 10px !important;
        display: block;
    }
    .margin-s-top-15 {
        margin-top: 15px !important;
        display: block;
    } 
    .margin-s-top-20 {
        margin-top: 20px !important;
        display: block;
    } 
    .margin-s-top-30 {
        margin-top: 30px !important; 
        display: block;
    } 
    .margin-s-top-40 {
        margin-top: 40px !important; 
        display: block;
    }
    .margin-s-top-50 {
        margin-top: 50px !important;
        display: block;
    }
    .margin-s-top-60 {
        margin-top: 60px !important;
        display: block;
    }
    .margin-s-top-70 {
        margin-top: 70px !important;
        display: block;
    }
    .margin-s-top-80 {
        margin-top: 80px !important;
        display: block;
    }
    .margin-s-bottom-0 {
        margin-bottom: 0 !important; 
        display: block;
    }
    .margin-s-bottom-10 {
        margin-bottom: 10px !important;
        display: block;
    }
    .margin-s-bottom-15 {
        margin-bottom: 15px !important; 
        display: block;
    } 
    .margin-s-bottom-20 {
        margin-bottom: 20px !important; 
        display: block;
    } 
    .margin-s-bottom-30 {
        margin-bottom: 30px !important; 
        display: block;
    } 
    .margin-s-bottom-40 {
        margin-bottom: 40px !important;
        display: block;
    }
    .margin-s-bottom-50 {
        margin-bottom: 50px !important;
        display: block;
    }
    .margin-s-bottom-60 {
        margin-bottom: 60px !important; 
        display: block;
    }
    .margin-s-bottom-70 {
        margin-bottom: 70px !important; 
        display: block;
    }
    .margin-s-bottom-80 {
        margin-bottom: 80px !important;
        display: block;
    }
    .margin-s-top-bottom-0 {
        margin-top: 0 !important; 
        margin-bottom: 0 !important;
        display: block; 
    }
    .margin-s-top-bottom-10 {
        margin-top: 10px !important; 
        margin-bottom: 10px !important;
        display: block; 
    }
    .margin-s-top-bottom-15 {
        margin-top: 15px !important;
        margin-bottom: 15px !important;
        display: block;
    } 
    .margin-s-top-bottom-20 {
        margin-top: 20px !important;  
        margin-bottom: 20px !important; 
        display: block;
    } 
    .margin-s-top-bottom-30 {
        margin-top: 30px !important; 
        margin-bottom: 30px !important; 
        display: block;
    } 
    .margin-s-top-bottom-40 {
        margin-top: 40px !important; 
        margin-bottom: 40px !important;
        display: block; 
    }
    .margin-s-top-bottom-50 {
        margin-top: 50px !important; 
        margin-bottom: 50px !important; 
        display: block;
    }
    .margin-s-top-bottom-60 {
        margin-top: 60px !important;
        margin-bottom: 60px !important; 
        display: block;
    } 
    .margin-s-top-bottom-70 {
        margin-top: 70px !important; 
        margin-bottom: 70px !important; 
        display: block;
    } 
    .margin-s-top-bottom-80 {
        margin-top: 80px !important;
        margin-bottom: 80px !important; 
        display: block;
    }
    
    .margin-s-left-0 {
        margin-left: 0 !important;
    }
    .margin-s-left-10 {
        margin-left: 10px !important;
    }
    .margin-s-left-15 {
        margin-left: 15px !important;
    } 
    .margin-s-left-20 {
        margin-left: 20px !important;
    } 
    .margin-s-left-30 {
        margin-left: 30px !important;
    } 
    .margin-s-left-40 {
        margin-left: 40px !important;
    }
    .margin-s-left-50 {
        margin-left: 50px !important;
    }
    .margin-s-left-60 {
        margin-left: 60px !important;
    }
    .margin-s-left-70 {
        margin-left: 70px !important;
    }
    .margin-s--80 {
        margin-left: 80px !important;
    }
    .margin-s-right-0 {
        margin-right: 0 !important;
    }
    .margin-s-right-10 {
        margin-right: 10px !important;
    }
    .margin-s-right-15 {
        margin-right: 15px !important;
    } 
    .margin-s-right-20 {
        margin-right: 20px !important;
    } 
    .margin-s-right-30 {
        margin-right: 30px !important;
    } 
    .margin-s-right-40 {
        margin-right: 40px !important;
    }
    .margin-s-right-50 {
        margin-right: 50px !important;
    }
    .margin-s-right-60 {
        margin-right: 60px !important;
    }
    .margin-s-right-70 {
        margin-right: 70px !important;
    }
    .margin-s-right-80 {
        margin-right: 80px !important;
    }
    .margin-s-left-right-0 {
        margin-left: 0 !important;
        margin-right: 0 !important;
    }
    .margin-s-left-right-10 {
        margin-left: 10px !important;
        margin-right: 10px !important;
    }
    .margin-s-left-right-15 {
        margin-left: 15px !important;
        margin-right: 15px !important;
    } 
    .margin-s-left-right-20 {
        margin-left: 20px !important;
        margin-right: 20px !important;
    } 
    .margin-s-left-right-30 {
        margin-left: 30px !important;
        margin-right: 30px !important;
    } 
    .margin-s-left-right-40 {
        margin-left: 40px !important;
        margin-right: 40px !important;
    }
    .margin-s-left-right-50 {
        margin-left: 50px !important;
        margin-right: 50px !important;
    }
    .margin-s-left-right-60 {
        margin-left: 60px !important;
        margin-right: 60px !important;
    } 
    .margin-s-left-right-70 {
        margin-left: 70px !important;
        margin-right: 70px !important;
    } 
    .margin-s-left-right-80 {
        margin-left: 80px !important;
        margin-right: 80px !important;
    }
    .text-s-size-12 {
      font-size: 12px !important;
      line-height: 1.4;
    }
    .text-s-size-16 {
        font-size: 16px !important;
        line-height: 1.4;
    }
    .text-s-size-20 {
        font-size: 20px !important;
        line-height: 1.4;
    }
    .text-s-size-25 {
        font-size: 25px !important;
        line-height: 1.4;
    }
    .text-s-size-30 {
        font-size: 30px !important;
        line-height: 1.4;
    }
    .text-s-size-40 {
        font-size: 40px !important;
        line-height: 1.4;
    }
    .text-s-size-50 {
        font-size: 50px !important;
        line-height: 1.4;
    }
    .text-s-size-60 {
        font-size: 60px !important;
        line-height: 1.4;
    }
    .text-s-size-70 {
        font-size: 70px !important;
        line-height: 1.4;
    }
} 

/* Typography */
.text-uppercase {
  text-transform: uppercase;
  line-height: 1;
}
.text-line-height-1 {
  line-height: 1;
}

/* Containers */
.text-padding {
  display: inline-block !important;
  padding: 15px 20px;
}
.text-padding-small {
  display: inline-block !important;
  padding: 7px 10px;
}  


/* Custom Template Styles */

h1, h2, h3, h4, h5, h6, .h1, .h2, .h3, .h4, .h5, .h6 {
  font-family: "Playfair Display";
}

blockquote {
  background: #f5f5f5 none repeat scroll 0 0;
  padding: 40px;
}

blockquote:before {
  display:none;
}
header.position-absolute {
  position: absolute;
  top: 0;
  width: 100%;
  z-index: 10;
}
.top-bar {
  padding: 0 2rem;
}
.top-bar-social li {
  border-left: 0 solid;
}
nav {
  border-bottom: 0px solid;
  border-bottom: 1px solid rgba(255, 255, 255, 0.09);
  padding: 0 2rem;
  position: relative;
  z-index: 2;
}
.logo-dark {
  display:none;
}
nav.fixed, .fixed nav {
  background: #fff;
  border-bottom: 1px solid rgba(0, 0, 0, 0.09);
  padding: 0 2em;
}
nav.fixed .top-nav li a, .fixed nav .top-nav li a {
  color: #444;  
}
nav.fixed .logo-white, .fixed nav .logo-white {
  display:none;
}
nav.fixed .logo-dark, .fixed nav .logo-dark {
  display:block;
}  
.background-transparent {
  background: none;
}

.logo img {
  margin: 0;
  max-width: 200px;
  position: relative;
  top: 12px;
  width: 100%;
}
.top-nav li a {
  color: #fff;
  padding: 1.5rem;
  opacity: 0.7;
  transition: all 0.20s linear 0s;
-o-transition: all 0.20s linear 0s;
-ms-transition: all 0.20s linear 0s;
-moz-transition: all 0.20s linear 0s;
-webkit-transition: all 0.20s linear 0s;
} 

.top-nav ul ul {
  background: #fff none repeat scroll 0 0;
}
.top-nav li ul li {
  border-bottom: 1px solid rgba(255, 255, 255, 0.05);
}
.top-nav li ul li:last-child {
  border-bottom: 0;
}
.top-nav li ul li a, .background-white .top-nav li ul li a, .top-nav .active-item li a {
  background: #fff none repeat scroll 0 0;
  color: rgba(0,0,0, 0.75);
}

.background-transparent-hightlight .top-nav .active-item > a, .background-transparent-hightlight .top-nav li a:hover, .background-transparent-hightlight .aside-nav li a:hover, .background-transparent-hightlight .aside-nav > ul > li.active-item > a:link, .background-transparent-hightlight .aside-nav > ul > li.active-item > a:visited {
  background: rgba(255, 255, 255, 0.08) none repeat scroll 0 0;
  color: #fff;
  opacity: 1;
}
nav.background-transparent-hightlight.fixed .top-nav .active-item > a, nav.background-transparent-hightlight.fixed .top-nav li a:hover, nav.background-transparent-hightlight.fixed .aside-nav li a:hover, nav.background-transparent-hightlight.fixed .aside-nav > ul > li.active-item > a:link, nav.background-transparent-hightlight.fixed .aside-nav > ul > li.active-item > a:visited {
  background: none;
  color: #000;
  opacity: 1;
}
.background-transparent-hightlight .top-nav ul ul .active-item a, .background-transparent-hightlight .top-nav ul ul li a:hover, .background-transparent-hightlight .aside-nav ul ul li a:hover, .background-transparent-hightlight .aside-nav > ul > li.active-item > a:link, .background-transparent-hightlight .aside-nav > ul > li.active-item > a:visited {
  color: #000;
}


/* Carousel Navigation*/
.owl-carousel .owl-dot span {
  height: 10px;
  margin: 0 5px;
  width: 10px;
  -ms-transform: rotate(45deg);
  -webkit-transform: rotate(45deg);
  transform: rotate(45deg);
}
.owl-carousel .owl-nav div {
  border: 0 none;
  color: #C9C9C9 !important;
  font-family: sli;
  font-size: 30px;
  height: auto;
  line-height: 0;
  width: auto;
}
.carousel-nav-white.owl-carousel .owl-nav div {
  border: 0;
}

/* Buttons */
.button, a.button, a.button:link, a.button:visited {
border: 0;
}

/* Image blocks */
.image-hover-zoom img {
  transition: all 0.50s cubic-bezier(0.645, 0.045, 0.355, 1) 0s;
  -o-transition: all 0.50s cubic-bezier(0.645, 0.045, 0.355, 1) 0s;
  -ms-transition: all 0.50s cubic-bezier(0.645, 0.045, 0.355, 1) 0s;
  -moz-transition: all 0.50s cubic-bezier(0.645, 0.045, 0.355, 1) 0s;
  -webkit-transition: all 0.50s cubic-bezier(0.645, 0.045, 0.355, 1) 0s;
}
.owl-item .image-testimonial-small {
  margin: 0 auto 20px;
  width: auto!important;
} 

video {
  width: 100%;
}

@media screen and (max-width:768px) {
  header.position-absolute {
    background: #fff none repeat scroll 0 0;
    position: relative;
  }
  .logo img {
    margin: 0 auto;
    max-width: 300px;
  }
  .logo img.logo-white {
    display:none;
  }
  .logo img.logo-dark {
    display:block;
  }
  .nav-text::after {
    color: #002633;
  }
  .fixed {
    position: relative;
    z-index: 10;
  }
  .fixed .nav-text::after {
    color: #002633;
  }
  .top-nav li a,.top-nav li ul li a {
    border-top: 1px solid #f5f5f5;
    color: #777;
    opacity: 1;
  }
  .top-nav li a, .background-white .top-nav li a {
    background: #fff none repeat scroll 0 0;
    font-size: 1.5em;
    padding: 1.2em 1em;
  }
  .top-nav li ul li a {
    background: #f5f5f5!important;
    font-size: 1.5em;
    padding: 1.2em 1em;
  }
  nav.fixed .top-nav li a, .fixed nav .top-nav li a {
    color: #777;  
  }
  .background-transparent-hightlight .top-nav .active-item > a, .background-transparent-hightlight .top-nav li a:hover, .background-transparent-hightlight .aside-nav li a:hover, .background-transparent-hightlight .aside-nav > ul > li.active-item > a:link, .background-transparent-hightlight .aside-nav > ul > li.active-item > a:visited {
    color: #000;
  }
  .carousel-3-blocks {
    padding: 0;
  }
  
}    

</style>
