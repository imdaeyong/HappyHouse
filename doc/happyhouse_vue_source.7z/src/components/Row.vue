<template>
  <tr>
    <td>{{ qnaNo }}</td>
    <td>
      <router-link :to="`/read?qnaNo=${qnaNo}`">{{ qnaTitle }}</router-link>
    </td>
    <td>{{ qnaUserid }}</td>
    <td>{{ getFormatDate(qnaDatetime) }}</td>
  </tr>
</template>

<script>
import moment from 'moment';
export default {
  name: 'row',
  props: {
    qnaNo: { type: Number },
    qnaUserid: { type: String },
    qnaTitle: { type: String },
    qnaDatetime: { type: String },
  },
  methods: {
    getFormatDate(qnaDatetime) {
      return moment(new Date(qnaDatetime)).format('YYYY.MM.DD');
    },
  },
};
</script>
