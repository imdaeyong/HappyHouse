<template>
  <div>
    <div class="form-group">
      <label for="qnaTitle">제목</label>
      <input
        type="text"
        class="form-control"
        id="qnaTitle"
        ref="qnaTitle"
        placeholder="제목을 입력하세요"
        v-model="qnaTitle"
      />
    </div>
    <div class="form-group">
      <label for="qnaContent">내용</label>
      <textarea
        type="text"
        class="form-control"
        id="qnaContent"
        ref="qnaContent"
        placeholder="내용을 입력하세요"
        rows="8"
        v-model="qnaContent"
      ></textarea>
    </div>
    <div class="text-right">
      <button
        class="btn btn-primary"
        v-if="type == 'create'"
        @click="checkHandler"
      >
        등록
      </button>
      <button class="btn btn-primary" v-else @click="checkHandler">수정</button>
      <button class="btn btn-primary" @click="moveList">목록</button>
    </div>
  </div>
</template>

<script>
import http from '@/util/http-common';
export default {
  name: 'qna-Form',
  props: {
    type: { type: String }
  },
  data: function() {
    return {
      qnaNo: '',
      qnaUserid: '',
      qnaTitle: '',
      qnaContent: '',
    };
  },
  methods: {
    checkHandler() {
      let err = true;
      let msg = '';
            
      err &&
        !this.qnaTitle &&
        ((msg = '제목 입력해주세요'), (err = false), this.$refs.qnaTitle.focus());
      err &&
        !this.qnaContent &&
        ((msg = '내용 입력해주세요'),
        (err = false),
        this.$refs.qnaContent.focus());

      if (!err) alert(msg);
      else this.type == 'create' ? this.createHandler() : this.updateHandler();
    },
    createHandler() {
      http
        .post('/qna', {
          qnaUserid: this.qnaUserid,
          qnaTitle: this.qnaTitle,
          qnaContent: this.qnaContent,
        })
        .then(({ data }) => {
          let msg = '등록 처리시 문제가 발생했습니다.';
          if (data === 'success') {
            msg = '등록이 완료되었습니다.';
          }
          alert(msg);
          this.moveList();
        })
        .catch(() => {
          alert('등록 처리시 에러가 발생했습니다.');
        });
    },
    updateHandler() {
      http
        .put(`/qna/${this.qnaNo}`, {
          qnaNo: this.qnaNo,
          qnaUserid: this.qnaUserid,
          qnaTitle: this.qnaTitle,
          qnaContent: this.qnaContent,
        })
        .then(({ data }) => {
          let msg = '수정 처리시 문제가 발생했습니다.';
          if (data === 'success') {
            msg = '수정이 완료되었습니다.';
          }
          alert(msg);
          this.moveList();
        })
        .catch(() => {
          alert('수정 처리시 에러가 발생했습니다.');
        });
    },
    moveList() {
      this.$router.push('/list');
    },
  },
  created() {
    if (this.type === 'update') {
      http
        .get(`/qna/${this.$route.query.qnaNo}`)
        .then(({ data }) => {
          this.qnaNo = data.qnaNo;
          this.qnaUserid = data.qnaUserid;
          this.qnaTitle = data.qnaTitle;
          this.qnaContent = data.qnaContent;
        })
        .catch(() => {
          alert('에러가 발생했습니다.');
        });
    }
  },
};
</script>

<style scoped></style>
