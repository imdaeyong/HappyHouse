<template>
  <div align="center">
    <table class="table table-bordered w-50">
      <tr>
        <th>번호</th>
        <td>{{ qnaNo }}</td>
      </tr>
      <tr>
        <th>글쓴이</th>
        <td>{{ qnaUserid }}</td>
      </tr>
      <tr>
        <th>제목</th>
        <td>{{ qnaTitle }}</td>
      </tr>
      <tr>
        <th>날짜</th>
        <td>{{ getFormatDate(qnaDatetime) }}</td>
      </tr>
      <tr>
        <td colspan="2">
          {{ qnaContent }}
        </td>
      </tr>
    </table>

    <br />
    <div class="text-center">
      <router-link to="/list"
        ><button class="btn btn-primary">목록</button></router-link
      >
      <router-link :to="'/update?qnaNo=' + qnaNo"
        ><button class="btn btn-primary">수정</button></router-link
      >
      <router-link :to="'/delete?qnaNo=' + qnaNo"
        ><button class="btn btn-primary">삭제</button></router-link
      >
    </div>
  </div>
</template>

<script>
import moment from 'moment';
export default {
  name: 'detail',
  props: {
    qnaNo: { type: Number },
    qnaUserid: { type: String },
    qnaTitle: { type: String },
    qnaContent: { type: String },
    qnaDatetime: { type: String },
  },
  methods: {
    getFormatDate(qnaDatetime) {
      return moment(new Date(qnaDatetime)).format('YYYY.MM.DD HH:mm:ss');
    },
  },
};
</script>
