<template>
  <footer class="w3-center w3-black w3-padding-16">
<!--   <p>Made by 김소희 오정엽</p> -->
  <p>Made by 오정엽 김대용</p>
</footer>
</template>

<script>
export default {

}
</script>

<style>
footer{
	margin-bottom: auto;
	}
</style>