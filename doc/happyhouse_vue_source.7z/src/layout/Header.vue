<template>
  <div >
    <div class="w3-top" style="width:1110px">
      <div class="w3-bar w3-white w3-wide w3-padding w3-card"  >
        <a href="/" class="w3-bar-item w3-button">
          <b>Happy</b> House
        </a>
        <!-- Float links to the right. Hide them on small screens -->
        <div class="w3-right w3-hide-small">
          <a href="/noticepage" class="w3-bar-item w3-button">공지사항</a>
          <a
            href="/moveFavList"
            class="w3-bar-item w3-button"
            style="text-decoration: none;"
          >관심지역 보기</a>
          <a
            href="/moveFavRegist"
            class="w3-bar-item w3-button"
            style="text-decoration: none;"
          >관심지역 등록</a>
          <a href="/mvmypage" style="cursor: pointer;text-decoration: none;">
            <strong style="color: #6495ED;">ssafy</strong>
          </a>님 환영합니다.
          <a href="/logout" class="w3-button w3-amber w3-padding">로그아웃</a>
        </div>
      </div>
    </div>
    <!-- Header -->
    <header class="w3-display-container w3-content w3-wide" style="max-width:1500px;" id="home">
      <img class="w3-image" src="../img/cityview.jpg" alt="Architecture" width="1500" />
      <div class="w3-display-middle w3-margin-top w3-center">
        <h1 class="w3-xxlarge w3-text-white">
          <span class="w3-padding w3-white w3-opacity-min">
            <b>Happy</b>
          </span>
          <span class="w3-hide-small w3-text-light-grey">House</span>
        </h1>
      </div>
    </header>

    <section class="section-small-padding background-white text-center container">
      <div class="line">
        <div class="margin">
          <div class="s-12 m-12 l-3 margin-m-bottom">
            <div class="padding block-bordered">
              <i>
                <img src="../img/aparts.png" />
              </i>
              <h2 class="text-thin">아파트 목록</h2>
              <a class="button button-dark-stroke text-size-12" href="/house/lists">MOVE</a>
            </div>
          </div>
          <div class="s-12 m-12 l-3 margin-m-bottom">
            <div class="padding block-bordered">
              <img src="../img/drugstore.png" />
              <h2 class="text-thin">주변 약국찾기</h2>
              <a class="button button-dark-stroke text-size-12" href="/drugstore">MOVE</a>
            </div>
          </div>
          <div class="s-12 m-12 l-3 margin-m-bottom">
            <div class="padding block-bordered">
              <img src="../img/mapsearch.png" />
              <h2 class="text-thin">지도로 검색</h2>
              <a class="button button-dark-stroke text-size-12" href="/map">MOVE</a>
            </div>
          </div>
          <div class="s-12 m-12 l-3 margin-m-bottom">
            <div class="padding block-bordered">
              <img src="../img/qna.png" />
              <h2 class="text-thin">QnA</h2>
              <a class="button button-dark-stroke text-size-12" href="/qna.html">MOVE</a>
            </div>
          </div>
        </div>
      </div>
    </section>
  </div>
</template>

<script>
export default {
  name: "AppHeader"
};
</script>

