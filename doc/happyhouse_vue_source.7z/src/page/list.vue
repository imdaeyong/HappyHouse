<template>
  <div>
    <div v-if="items.length">
      <table class="table table-bordered table-condensed text-center">
        <colgroup>
          <col :style="{ width: '8%' }" />
          <col :style="{ width: '40%' }" />
          <col :style="{ width: '10%' }" />
          <col :style="{ width: '20%' }" />
        </colgroup>
        <tr>
          <th>번호</th>
          <th>제목</th>
          <th>작성자</th>
          <th>날짜</th>
        </tr>
        <list-row
          v-for="(item, index) in items"
          :key="`${index}_items`"
          :qnaNo="item.qnaNo"
          :qnaTitle="item.qnaTitle"
          :qnaUserid="item.qnaUserid"
          :qnaDatetime="item.qnaDatetime"
        />
      </table>
    </div>
    <div v-else>글이 없습니다.</div>
    <div class="text-right">
      <button class="btn btn-primary" @click="movePage">등록</button>
    </div>
  </div>
</template>

<script>
import http from '@/util/http-common';
import ListRow from '@/components/Row.vue';
export default {
  name: 'list',
  components: {
    ListRow,
  },
  data: function() {
    return {
      items: [],
    };
  },
  created() {
    http
      .get('/qna')
      .then(({ data }) => {
        console.log(data);
        this.items = data;
      })
      .catch(() => {
        alert('에러가 발생했습니다.');
      });
  },
  methods: {
    movePage() {
      this.$router.push('/create');
    },
  },
};
</script>

<style></style>
